# RSM-2026-0310 Revision 1: reproducibility code and data

This is a **code-and-data-only** release for the revised manuscript
"Contrast-Level Aggregate-Data Dose-Response Meta-Analysis for Heterogeneous Exposure Intervals".
The author's private point-by-point reviewer response, highlighted manuscript, and
Supplement PDFs are not posted in this public code repository. The original August
2026 code-and-data release at the repository root remains unchanged.

All scripts, current machine-readable numerical outputs, and required extracted
original implementation/data modules needed for the revision are included under
this archive's folder structure. No file from the journal's private review process
is included.

## No missing external local-directory dependency

`original_release/IntervalDRMA/code/interval_drma_core.py` and the corresponding
original data are included as extracted files. No manual extraction into a hidden
absolute path is required. All current scripts resolve paths relative to their own
location; keep the folder structure intact. All analyses use local inputs, not a
network request. The original extracted code and input data are preserved without modification.

## Reproduce the current numerical results

Use Python 3.13 (tested version and package versions are in `ENVIRONMENT.json`).
Create and activate a virtual environment, then from this folder run:

```sh
python -m pip install -r requirements.txt
python final_analysis/run_focused_revision.py --validate --applications
python final_analysis/run_focused_revision.py --coverage --outer 1000 --inner 999 --workers 4
python final_analysis/source_audits.py
python final_analysis/make_figures.py
python validate_recovered_analyses.py
python original_release/IntervalDRMA/code/test_intervaldrma.py
python -m unittest discover -s final_analysis -p test_revision.py -v
```

Set `OPENBLAS_NUM_THREADS=1` and `OMP_NUM_THREADS=1` before starting Python to avoid
oversubscription. In a POSIX shell, use `export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1`.
In PowerShell, use `$env:OPENBLAS_NUM_THREADS='1'; $env:OMP_NUM_THREADS='1'`.
The coverage run is parallel across independent tasks; reduce `--workers` for a
smaller computer. Changing the worker count does not change the task seed streams.
Do not lower the replicate counts when recreating the manuscript results.

The finite-study experiment has eight cells, **1,000 outer datasets and 999 inner
replicates per cell**, with 50 resampled empirical covariance/support templates per
cell. K is 8 or 10 with heterogeneity multipliers 0, 0.5, and 1; K is 20 or 30 at the
full reference heterogeneity. The master seed entropy is 202610171; cell/chunk
SeedSequence streams are recorded in the code. The application bootstraps use
**9,999** replicates with their own recorded seeds. `bootstrap_outer_records.csv`
contains all 8,000 outer-dataset records. Elapsed time is descriptive and is not a
reproducibility target.

The fast solver is an exact scalar reduction of the existing fixed-design,
one-random-slope REML likelihood, not a different statistical model. Its estimates
were compared against the original full-contrast solver on 300 datasets; see
`solver_validation.json`. This reduction is used only for the linear conditional
fits, not the two-basis nonlinear fit or CR2 calculation.

## Reproduce the adjusted-OR, M2, and generic factorial settings

```sh
python final_analysis/reproduce_archived_checks.py --m2 --adjusted --factorial
```

This command uses the following explicitly fixed settings:

- M2: 500 replicates per structure, seed 20261002, K=8, beta=-0.0637039001,
  tau=0.1172230589, as in the archived M2 setting. It does not retroactively describe
  this archived setting as the current source-informed empirical fit.
- Adjusted ORs: 500 replicates per condition, seed 20261001, K=10, 1,500 participants
  per study, beta=-0.08 (or 0 in the null setting), tau=0.06. Exposure/covariate and
  logistic models are unchanged. **The current manuscript uses the regenerated
  output `final_analysis/results/adjusted_or_current.json`.**
- Generic factorial: 64 resolution-IV cells, **500** replicates per cell; base seed
  202610062 and cell offset 7919. The supplied replay uses the same original design.
  The cell-level archive is `revision_analysis_bundle/rsm_generic_factorial_cells.csv`.

### Adjusted-OR checkpoint provenance

The earlier stored `rsm_adjusted_or_sim_paired500.json` does not numerically match a
new run of its supplied seeded generator. That earlier file has **not** been
silently replaced. The discrepancy is recorded in
`final_analysis/results/archive_verification/adjusted_checkpoint_differences.json`.
The same generator/settings were run again and the regenerated results agreed;
these current results replace the earlier numerical checkpoint in the manuscript,
Supplementary Table S30, and response. The cause of the old checkpoint mismatch
has not been established. The old JSON remains historical, not the current result.
M2 and the generic-factorial summaries were separately replayed and checked against
their preserved outputs.

The archived files `rsm_bootstrap_coverage_final.json`,
`rsm_radon_first_stage_plausibility_final.json`, and other earlier revision outputs
are also historical. The small 200 x 199 bootstrap checkpoint is superseded by the
expanded eight-cell experiment. Do not use those old files in place of the current
results below. The older `rsm_revision_final_simulations.py` is retained for
provenance, not as the current manuscript's entry point.

## Output-to-manuscript map

| Current output under `final_analysis/results/` | Manuscript use |
|---|---|
| `application_checks.json` | Main Table 1; AFO Section 3.2; restrictions; S24 Schultz; S25 paired bounds; S26 nonlinear contrasts; Figure 2A |
| `bootstrap_coverage.json`, `bootstrap_outer_records.csv` | Main Table 8; Supplementary Table S18; finite-study reporting recommendation |
| `radon_source_audit.json`, `radon_primary_contrasts.csv` | Main radon Section 3.1/Table 2; Supplementary Tables S20-S22; Figure 2B |
| `afo_probability_audit.json`, `.csv` | Supplementary Table S23; reported/original/recalibrated probabilities |
| `adjusted_or_current.json` | Current adjusted-OR results, main Section 3.3 and Supplementary Table S30 |
| `solver_validation.json` | Numerical-equivalence checks in Supplementary Methods S8 |

`calibration_audit/recovered_analysis_audit.json`, regenerated by the audit script,
records the Rasmussen lookup repair, all completed source calibrations, and the
unchanged archive hashes. The original input workbook is never edited. The current
AFO design applies the recorded Rasmussen calibration rather than silently falling
back to its regional parameter entry.

## Source information and limits

The exact source counts, original reporting units, control populations, cutpoints,
URLs/DOIs, and inclusion decisions are in `source_audits.py`,
`radon_source_audit.json`, and Supplementary Tables S20-S21. Source PDFs are not
redistributed. For the current principal radon mapping:

- Alavanja 1994 uses 1,183 individual controls (counts 233, 242, 233, 252, 223).
- Pershagen 1994 uses 2,576 classified analytic controls (952, 561, 568, 436, 59),
  not the larger enrollment denominator 2,847.
- The preliminary New Jersey counts and dwelling-level/otherwise mismatched
  summaries are sensitivities, not asserted exact source-population matches.
- Darby's pooled European bounded-category means are a concordance check, not a
  direct validation of the UK study. The unmatched open upper category is not
  assigned a mean from a bounded 400-799 category.

All reporting-precision decisions and the unchanged outcome-support extraction are
explicit in the source audit. Calibration to its own counts is not independent
validation of within-category means. Outcome-independent selection of exposure
information does not make estimated control counts statistically independent of
ORs from the same participants. The reported intervals remain conditional on the
specified support representatives and covariance; the simulation does not resolve
first-stage estimation uncertainty, transportability, residual confounding, or
covariance misspecification. The four-study strict AFO restriction is descriptive.
The unrecoverable historical raw geospatial fits remain an explicit limitation.

## Publication and verification

The versioned GitHub revision archive is additive to the August 2026 release.
The revision numerical results correspond to the main and Supplement tables
specified above. The supplied validation files document the 32 original/revision
tests and the numerical comparison of the fast REML implementation. The complete
8,000-record outer-simulation CSV accompanies the code; re-running the nested
bootstrap is computationally costly and is not necessary simply to inspect the
stored results. The historical raw geospatial data underlying some first-stage AFO
fits were not retained, as disclosed in the manuscript and in the source audit.

Full scientific methods and manuscript PDF are provided through the journal revision,
not this public code-and-data repository. The data and simulations are not to be
interpreted as independent validation of all first-stage assumptions.
