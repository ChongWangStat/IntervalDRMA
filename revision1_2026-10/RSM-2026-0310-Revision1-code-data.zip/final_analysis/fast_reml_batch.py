"""Exact one-random-slope profile REML, using sufficient study slope statistics.

For fixed x_k and Sigma_k, z_k=(x_k' Sigma_k^-1 y_k)/a_k and v_k=1/a_k,
a_k=x_k' Sigma_k^-1 x_k. The residual component orthogonal to x_k is
independent of tau; dropping it changes neither the REML minimizer nor beta/SE.
This is a computational reduction of the existing likelihood, not a new model.
"""
from __future__ import annotations
import math
import numpy as np
from numba import njit

@njit(cache=True)
def objective(u, z, v, scale):
    tau = math.expm1(u)*scale
    t2 = tau*tau
    sw=0.0; swz=0.0; logdet=0.0
    for i in range(len(v)):
        vv=v[i]+t2; w=1.0/vv
        sw+=w; swz+=w*z[i]; logdet+=math.log(vv)
    b=swz/sw; q=0.0
    for i in range(len(v)):
        q+=(z[i]-b)**2/(v[i]+t2)
    return 0.5*(logdet+math.log(sw)+q)

@njit(cache=True)
def fit_one(z, v):
    scale=math.sqrt(np.mean(v))
    # Find a bracket on the tau scale, then use a coarse global scan to
    # detect separated local minima before bounded golden-section refinements.
    upper=max(scale, math.sqrt(np.mean((z-z.mean())**2)))
    prev=objective(0.,z,v,scale)
    for j in range(40):
        curr=objective(math.log1p(upper/scale),z,v,scale)
        if curr>=prev: break
        prev=curr; upper*=2.
    umax=math.log1p(upper/scale)
    ngrid=32
    ugrid=np.linspace(0.,umax,ngrid+1)
    vals=np.empty(ngrid+1)
    for j in range(ngrid+1): vals[j]=objective(ugrid[j],z,v,scale)
    best=vals[0]; bestu=0.
    golden=(math.sqrt(5.)-1.)/2.
    for j in range(1,ngrid):
        if vals[j]>vals[j-1] or vals[j]>vals[j+1]: continue
        lo=ugrid[j-1]; hi=ugrid[j+1]
        c=hi-golden*(hi-lo); d=lo+golden*(hi-lo)
        fc=objective(c,z,v,scale); fd=objective(d,z,v,scale)
        for it in range(70):
            if hi-lo<2e-10: break
            if fc<fd:
                hi=d; d=c; fd=fc; c=hi-golden*(hi-lo); fc=objective(c,z,v,scale)
            else:
                lo=c; c=d; fc=fd; d=lo+golden*(hi-lo); fd=objective(d,z,v,scale)
        uu=(lo+hi)/2.; vv=objective(uu,z,v,scale)
        if vv<best: best=vv; bestu=uu
    # A small positive optimum in the first grid segment can be missed by
    # nodewise local-minimum detection. Always search that boundary segment.
    lo=0.; hi=ugrid[1]
    c=hi-golden*(hi-lo); d=lo+golden*(hi-lo)
    fc=objective(c,z,v,scale); fd=objective(d,z,v,scale)
    for it in range(70):
        if hi-lo<2e-10: break
        if fc<fd:
            hi=d; d=c; fd=fc; c=hi-golden*(hi-lo); fc=objective(c,z,v,scale)
        else:
            lo=c; c=d; fc=fd; d=lo+golden*(hi-lo); fd=objective(d,z,v,scale)
    uu=(lo+hi)/2.; vv=objective(uu,z,v,scale)
    if vv<best: best=vv; bestu=uu
    if vals[0]<=best+1e-10*(1.+abs(best)): bestu=0.
    tau=math.expm1(bestu)*scale
    w=1./(v+tau*tau); sw=w.sum(); b=(w*z).sum()/sw
    se=math.sqrt(1./sw); q=(w*(z-b)**2).sum()/(len(v)-1)
    return b,tau,se,q

@njit(cache=True)
def fit_batch(z, v):
    out=np.empty((len(z),4))
    for j in range(len(z)):
        out[j,:]=fit_one(z[j,:],v)
    return out
