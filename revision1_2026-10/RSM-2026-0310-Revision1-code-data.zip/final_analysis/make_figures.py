#!/usr/bin/env python3
"""Recreate the submitted comparison layout with current reviewer-requested fits.

The AFO panel retains the submitted slope scale and four analysis rows.
The radon panel retains the five submitted comparisons and adds the revised
source-informed primary row. All plotted intervals are Normal, to isolate the
mapping/restriction comparison. Principal bootstrap intervals are in the text.
No analyses are fitted by this script.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz

R = Path(__file__).resolve().parent.parent
A = json.loads((R/'final_analysis/results/application_checks.json').read_text())
D = json.loads((R/'final_analysis/results/radon_source_audit.json').read_text())
(R/'images').mkdir(exist_ok=True)

def panel(name, labels, fits, title, xlabel, scale):
    y = np.arange(len(labels))[::-1]
    x = np.array([f['beta'] if scale == 'slope' else f['OR'] for f in fits])
    ci = np.array([f['intervals']['normal'] if scale == 'slope' else f['OR_intervals']['normal'] for f in fits])
    fig = plt.figure(figsize=(5.8, 3.65))
    ax = fig.add_subplot(111)
    ax.errorbar(x, y, xerr=np.vstack((x-ci[:,0],ci[:,1]-x)),fmt='o',capsize=3,markersize=4)
    ax.axvline(0 if scale == 'slope' else 1,linestyle=':',linewidth=1)
    ax.set_yticks(y,labels,fontsize=9)
    ax.set_ylim(-0.55,len(labels)-0.45)
    ax.set_title(title,loc='left',fontsize=11)
    ax.set_xlabel(xlabel,fontsize=10)
    ax.tick_params(axis='x',labelsize=9)
    ax.spines[['top','right']].set_visible(False)
    fig.tight_layout()
    fig.savefig(R/'images'/name,bbox_inches='tight')
    plt.close(fig)

panel('AFO_score_comparison_current.pdf',
 ['All mapped contrasts\nconditional mean (primary)', 'All mapped contrasts\nmidpoint', 'OR-only\nrestriction', 'Explicit-support OR\nrestriction'],
 [A['afo_main'], A['afo_assigned_value']['finite_midpoint'], A['afo_restrictions']['OR_only'], A['afo_restrictions']['strict_explicit_OR']],
 'A. AFO illustration', r'Random-effects slope, $\hat\beta_1$ per mile','slope')
panel('Radon_score_comparison_current.pdf',
 ['Source-informed\nLognormal (primary)', 'Historical national\nLognormal', 'UNSCEAR 2024\nfallback', 'Midpoint; open tail\n1.2 x lower bound', 'Midpoint; open tail\n1.5 x lower bound', 'Midpoint; open tail\n2.0 x lower bound'],
 [D['primary'],D['national_only'],D['external_2024_elsewhere'],*D['assigned_value'].values()],
 'B. Residential-radon illustration',r'Random-effects OR per 100 Bq/m$^3$','OR')
left=fitz.open(R/'images/AFO_score_comparison_current.pdf')
right=fitz.open(R/'images/Radon_score_comparison_current.pdf')
width=max(left[0].rect.width,right[0].rect.width)
height=max(left[0].rect.height,right[0].rect.height)
out=fitz.open();page=out.new_page(width=2*width+8,height=height)
page.show_pdf_page(fitz.Rect(0,0,width,height),left,0)
page.show_pdf_page(fitz.Rect(width+8,0,2*width+8,height),right,0)
path=R/'images/Score_assumption_comparison_original_based.pdf'
if path.exists(): path.unlink()
out.save(path)
print('Recreated original-layout comparison with current fits:',path)
