"""Replay archived M2/factorial settings and regenerate the current adjusted-OR run.
The old adjusted-OR checkpoint is preserved. Its differences from the regenerated
seeded run are recorded explicitly, and adjusted_or_current.json is the current
manuscript source. This script does not replace the strengthened bootstrap.
"""
from pathlib import Path
import argparse, json, sys, subprocess
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'revision_analysis_bundle'))
import rsm_revision_sensitivity as rr
import rsm_revision_remaining_analyses as old

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--factorial',action='store_true');ap.add_argument('--adjusted',action='store_true');ap.add_argument('--m2',action='store_true');args=ap.parse_args()
    out=HERE/'results'/'archive_verification';out.mkdir(exist_ok=True)
    if args.m2:
        expected=json.loads((ROOT/'revision_analysis_bundle/rsm_m2_structured_corr_sim.json').read_text())
        subprocess.run([sys.executable,str(ROOT/'revision_analysis_bundle/run_m2_sim.py')],check=True)
        actual=json.loads((ROOT/'revision_analysis_bundle/rsm_m2_structured_corr_sim.json').read_text())
        for k in expected:
            for v in expected[k]:np.testing.assert_allclose(actual[k][v],expected[k][v],atol=1e-6,rtol=1e-6)
        (out/'m2_verified.json').write_text(json.dumps(actual,indent=2))
    if args.adjusted:
        expected=json.loads((ROOT/'revision_analysis_bundle/rsm_adjusted_or_sim_paired500.json').read_text())
        actual=rr.adjusted_or_sim(seed=20261001,R=500,K=10,n=1500,beta=-.08,tau=.06)
        (out/'adjusted_regenerated.json').write_text(json.dumps(actual,indent=2))
        # Keep the old checkpoint unchanged and explicitly record differences.
        differences={k:{f:actual[k][f]-v for f,v in expected[k].items()
                       if f in actual[k] and isinstance(v,(float,int)) and actual[k][f]!=v}
                     for k in expected if k in actual}
        (out/'adjusted_checkpoint_differences.json').write_text(json.dumps(differences,indent=2))
        (HERE/'results/adjusted_or_current.json').write_text(json.dumps(actual,indent=2))
    if args.factorial:
        expected=json.loads((ROOT/'revision_analysis_bundle/rsm_factorial_final.json').read_text())
        actual=old.run_generic_factorial(replicates=500)
        (out/'factorial_regenerated.json').write_text(json.dumps(actual,indent=2))
        # The preserved file has the same generic-factorial schema.
        e=expected.get('generic_factorial',expected)
        for k,v in e.get('overall',{}).items():
            if isinstance(v,(float,int)) and k in actual['overall']:
                np.testing.assert_allclose(actual['overall'][k],v,atol=1e-6,rtol=1e-6)
    print('Requested archived checks finished.')
if __name__=='__main__':main()
