#!/usr/bin/env python3
"""RSM Revision 1 focused final analyses: only Reviewer 1 M2--M4 and R2 C5.

Run from any working directory. See README_REPRODUCE.md for exact final commands.
All stochastic tasks use independent, explicitly recorded SeedSequence streams.
"""
from __future__ import annotations
import argparse, csv, json, math, os, sys, time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from scipy.stats import norm, t, gamma
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'revision_analysis_bundle'))
sys.path.insert(0,str(ROOT/'original_release'/'IntervalDRMA'/'code'))
from fast_reml_batch import fit_batch, fit_one
import rsm_revision_sensitivity as rr
from interval_drma_core import FastReml, Study
RESULTS=HERE/'results'; RESULTS.mkdir(exist_ok=True)
SEED=202610171


def save_json(path, obj):
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8'); temp.replace(path)


def afo_inputs():
    rows=rr.read_rows(ROOT/'revision_analysis_bundle'/'Observed Data.xlsx')
    sp=rr.source_params(rows)
    row=next(r for r in rows if r.refid==32509566)
    sp[(row.refid,rr.row_group(row))]=sp[(row.refid,'default')]
    x=rr.design(rows,sp,use_source=True)
    return rows,sp,x


def project_blocks(rows,x,kind='exchangeable',rho=.5):
    studies=[]; xs=[]; ys=[]; zs=[]; vs=[]; weights=[]
    for sid,ix,S,C in rr.cov_blocks(rows,kind,rho):
        xx=x[ix]; yy=np.array([rows[i].y for i in ix]); a=xx@np.linalg.solve(S,xx)
        if a<=0: raise ValueError('This scalar projection requires each block to be informative')
        z=xx@np.linalg.solve(S,yy)/a
        studies.append(Study(int(sid),[],S)); xs.append(xx); ys.append(yy)
        zs.append(z); vs.append(1./a); weights.append(np.linalg.solve(S,xx)/a)
    return studies,xs,ys,np.array(zs),np.array(vs),weights


def summarize_fit(z,v,k,bootstrap=9999,seed=SEED,scale=1.):
    fit=fit_batch(z[None,:],v)[0]
    b,tau,se,q=map(float,fit); tc=t.ppf(.975,k-1)
    ci={'normal':[b-1.96*se,b+1.96*se], 'study_t':[b-tc*se,b+tc*se],
        'modified_HK':[b-tc*se*math.sqrt(max(1.,q)),b+tc*se*math.sqrt(max(1.,q))]}
    if bootstrap:
        rng=np.random.default_rng(seed)
        zb=b+rng.normal(size=(bootstrap,k))*np.sqrt(v+tau*tau)
        fb=fit_batch(zb,v); piv=(fb[:,0]-b)/fb[:,2]
        quant=np.quantile(piv,[.025,.975]); ci['studentized_bootstrap']=[b-quant[1]*se,b-quant[0]*se]
        zero=float(np.mean(fb[:,1]==0.))
    else: zero=None
    return dict(beta=b,tau=tau,se=se,HK_q=q,K=k,intervals=ci,
        OR=math.exp(scale*b),OR_intervals={a:np.exp(scale*np.array(c)).tolist() for a,c in ci.items()},
        bootstrap_replicates=bootstrap,bootstrap_seed=seed if bootstrap else None,bootstrap_zero_rate=zero)


def validate_batch(n=300):
    rows,sp,x=afo_inputs(); studies,xs,ys,z,v,_=project_blocks(rows,x)
    rng=np.random.default_rng(SEED+1); errors=[]; disagreements=[]
    for j in range(n):
        k=[8,10,20,30][j%4]
        ix=rng.choice(8,k,replace=True)
        ss=[studies[i] for i in ix]; xx=[xs[i] for i in ix]
        tau=[0.,.03,.06,.118,.24][j%5]; beta=-.06092
        yy=[(beta+rng.normal(0.,tau))*a+np.linalg.cholesky(s.sigma)@rng.normal(size=len(a)) for a,s in zip(xx,ss)]
        zz=np.array([a@np.linalg.solve(s.sigma,b)/(a@np.linalg.solve(s.sigma,a)) for a,s,b in zip(xx,ss,yy)])
        vv=v[ix]
        reference=FastReml(ss,xx).fit_detailed(yy)
        result=fit_batch(zz[None,:],vv)[0]
        err=np.abs(result[:3]-np.array([reference['beta'],reference['tau'],reference['se_beta']]))
        errors.append(err.tolist())
        if np.max(err)>2e-6: disagreements.append({'rep':j,'errors':err.tolist()})
    report={'datasets':n,'max_abs_error_beta_tau_se':np.max(errors,axis=0).tolist(),
            'tolerance':2e-6,'disagreements':disagreements,
            'description':'Compared projected batch REML against original full-contrast FastReml on identical simulated datasets.'}
    save_json(RESULTS/'solver_validation.json',report)
    if disagreements: raise RuntimeError(report)
    print(json.dumps(report),flush=True)


def coverage_task(task):
    cell,k,tau_mult,chunk,n_outer,n_inner,templates,beta_true,tau_ref,basev=task
    seedseq=np.random.SeedSequence([SEED,cell,chunk]); rng=np.random.default_rng(seedseq)
    records=[]
    # Every chunk has five fixed templates; ten chunks give 50 templates/cell.
    picks=rng.choice(len(basev),size=(templates,k),replace=True)
    tau_true=tau_ref*tau_mult; tc=float(t.ppf(.975,k-1))
    for j in range(n_outer):
        tid=j%templates; v=basev[picks[tid]]
        z=beta_true+rng.normal(size=k)*np.sqrt(v+tau_true*tau_true)
        b,tau,se,q=fit_one(z,v)
        zb=b+rng.normal(size=(n_inner,k))*np.sqrt(v+tau*tau)
        fb=fit_batch(zb,v); piv=(fb[:,0]-b)/fb[:,2]
        quant=np.quantile(piv,[.025,.975])
        intervals={'normal':(b-1.96*se,b+1.96*se),'study_t':(b-tc*se,b+tc*se),
            'modified_HK':(b-tc*se*math.sqrt(max(1.,q)),b+tc*se*math.sqrt(max(1.,q))),
            'studentized':(b-quant[1]*se,b-quant[0]*se)}
        rec={'cell':cell,'K':k,'tau_multiplier':tau_mult,'chunk':chunk,'replicate':j,
             'template':tid,'beta':b,'tau':tau,'se':se,'q':q,'inner_zero_rate':float(np.mean(fb[:,1]==0.))}
        for name,(lo,hi) in intervals.items():
            rec[name+'_cover']=int(lo<=beta_true<=hi); rec[name+'_width']=hi-lo
        records.append(rec)
    return records


def run_coverage(outer=1000,inner=999,workers=4):
    rows,sp,x=afo_inputs(); studies,xs,ys,z,v,_=project_blocks(rows,x)
    f=fit_one(z,v); beta,tau_ref=float(f[0]),float(f[1])
    conditions=[(8,0.),(8,.5),(8,1.),(10,0.),(10,.5),(10,1.),(20,1.),(30,1.)]
    n_chunks=10
    counts=np.full(n_chunks,outer//n_chunks,dtype=int); counts[:outer%n_chunks]+=1
    all_records=[]; tasks=[]
    for cell,(k,mult) in enumerate(conditions):
        for chunk,n in enumerate(counts):
            if n: tasks.append((cell,k,mult,chunk,int(n),inner,5,beta,tau_ref,v))
    start=time.time()
    with ProcessPoolExecutor(max_workers=workers) as ex:
        fs=[ex.submit(coverage_task,task) for task in tasks]
        for num,future in enumerate(as_completed(fs),1):
            all_records+=future.result()
            if num%10==0: print(f'coverage chunks {num}/{len(fs)}; elapsed {time.time()-start:.1f}s',flush=True)
    all_records.sort(key=lambda r:(r['cell'],r['chunk'],r['replicate']))
    with (RESULTS/'bootstrap_outer_records.csv').open('w',newline='') as fh:
        w=csv.DictWriter(fh,fieldnames=list(all_records[0])); w.writeheader(); w.writerows(all_records)
    summary=[]
    for cell,(k,mult) in enumerate(conditions):
        rs=[r for r in all_records if r['cell']==cell]
        item={'K':k,'tau_multiplier':mult,'tau_true':mult*tau_ref,'beta_true':beta,
              'outer':len(rs),'inner':inner,'templates':n_chunks*5,
              'outer_zero_rate':float(np.mean([r['tau']==0. for r in rs])),
              'mean_inner_zero_rate':float(np.mean([r['inner_zero_rate'] for r in rs]))}
        for key in ['normal','study_t','modified_HK','studentized']:
            p=float(np.mean([r[key+'_cover'] for r in rs]));
            item[key]={'coverage':p,'mcse':math.sqrt(p*(1-p)/len(rs)),
                       'mean_width':float(np.mean([r[key+'_width'] for r in rs]))}
        summary.append(item)
    out={'seed_entropy':SEED,'elapsed_seconds':time.time()-start,
         'simulation':'Independent study slope sufficient statistics generated exactly under fixed contrast supports and sampling covariance; 50 resampled empirical templates/cell. No first-stage estimation.',
         'conditions':summary}
    save_json(RESULTS/'bootstrap_coverage.json',out); print(json.dumps(out,indent=2),flush=True)


def application_checks():
    rows,sp,x=afo_inputs(); studies,xs,ys,z,v,weights=project_blocks(rows,x)
    out={'afo_main':summarize_fit(z,v,len(z),bootstrap=9999,seed=SEED+10)}
    # Paired bound sensitivity: change only operational substitutes, not observed endpoints.
    out['paired_dmax']=[]
    for mult in [.8,1.,1.2]:
        for scoring in ['conditional_mean','finite_midpoint']:
            xx=rr.design(rows,sp,use_source=True,dmax_mult=mult,assigned_rule=None if scoring=='conditional_mean' else 'finite_midpoint')
            _,_,_,zz,vv,_=project_blocks(rows,xx)
            f=summarize_fit(zz,vv,len(zz),bootstrap=0)
            out['paired_dmax'].append({'multiplier':mult,'scoring':scoring,**f})
    # One prespecified middle evaluation: 2 miles versus 5 miles; not selected by OR/SE.
    ix=np.array([i for i,r in enumerate(rows) if r.refid!=rr.SCHULTZ or abs(r.c_hi-2.)<1e-10])
    subrows=[rows[i] for i in ix]; xx=x[ix]
    _,_,_,zz,vv,_=project_blocks(subrows,xx)
    one=summarize_fit(zz,vv,len(zz),bootstrap=9999,seed=SEED+11)
    schidx=[s.refid for s in studies].index(rr.SCHULTZ)
    for f,v0 in [(out['afo_main'],v),(one,vv)]:
        w=1./(v0+f['tau']**2); f['Schultz_information_fraction']=float(w[schidx]/w.sum())
    out['Schultz_single_middle_point']=one
    # Current full-data restrictions and working-correlation sensitivities.
    out['afo_restrictions']={}
    for name,keep in [('OR_only',[i for i,r in enumerate(rows) if r.effect_measure=='OR']),
                      ('strict_explicit_OR',[i for i,r in enumerate(rows) if r.effect_measure=='OR' and r.mapping_type==1])]:
        _,_,_,zz,vv,_=project_blocks([rows[i] for i in keep],x[keep]);
        out['afo_restrictions'][name]=summarize_fit(zz,vv,len(zz),bootstrap=9999,seed=SEED+20+len(keep))
    out['afo_structured']={}
    for kind in ['structured_moderate','structured_strong']:
        _,_,_,zz,vv,_=project_blocks(rows,x,kind)
        out['afo_structured'][kind]=summarize_fit(zz,vv,len(zz),bootstrap=0)
    out['afo_rho_grid']={}
    for rho in [0.,.25,.5,.75,.9]:
        _,_,_,zz,vv,_=project_blocks(rows,x,rho=rho)
        out['afo_rho_grid'][str(rho)]=summarize_fit(zz,vv,len(zz),bootstrap=0)
    out['afo_assigned_value']={}
    for rule in ['finite_midpoint','equal_adjacent_width','upper_1p2']:
        xx=rr.design(rows,sp,use_source=True,assigned_rule=rule)
        _,_,_,zz,vv,_=project_blocks(rows,xx)
        out['afo_assigned_value'][rule]=summarize_fit(zz,vv,len(zz),bootstrap=0)
    # Reproduce nonlinear fit, returning its full covariance for fixed-support comparisons.
    extra=rr.design(rows,sp,use_source=True,basis='log1p')
    ff=rr.fit_reml(rows,x,X_extra=extra)
    info=np.zeros((2,2))
    for _,ix,S,_ in rr.cov_blocks(rows):
        X=np.column_stack([x[ix],extra[ix]]); V=S+ff['tau']**2*np.outer(x[ix],x[ix]); info+=X.T@np.linalg.solve(V,X)
    cov=np.linalg.inv(info)
    nonlinear={'fit':ff,'coefficient_covariance':cov.tolist(),'point_comparisons':[]}
    # Display existing fitted population-average support curves, no refit/new method.
    for a,b in [(1.,5.),(2.,5.),(3.,5.)]:
        h=np.array([a-b,math.log1p(a)-math.log1p(b)])
        lin=(a-b)*out['afo_main']['beta']; nl=h@np.array(ff['beta']); se=math.sqrt(h@cov@h)
        nonlinear['point_comparisons'].append({'comparison':a,'reference':b,'linear_OR':math.exp(lin),'nonlinear_OR':math.exp(nl),'nonlinear_normal_CI':np.exp([nl-1.96*se,nl+1.96*se]).tolist()})
    out['nonlinear']=nonlinear
    # Residual diagnostics of current main fit.
    residual=[]
    for s,a,y in zip(studies,xs,ys):
        V=s.sigma+out['afo_main']['tau']**2*np.outer(a,a)
        residual.extend(np.linalg.solve(np.linalg.cholesky(V),y-out['afo_main']['beta']*a).tolist())
    out['afo_main']['Q']=float(np.sum(np.square(residual)))
    out['afo_main']['max_abs_whitened_residual']=float(np.max(np.abs(residual)))
    save_json(RESULTS/'application_checks.json',out)
    print(json.dumps(out,indent=2),flush=True)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--coverage',action='store_true'); ap.add_argument('--applications',action='store_true'); ap.add_argument('--validate',action='store_true');
    ap.add_argument('--outer',type=int,default=1000); ap.add_argument('--inner',type=int,default=999); ap.add_argument('--workers',type=int,default=4)
    args=ap.parse_args()
    if args.outer < 10 or args.inner < 99 or args.workers < 1:
        ap.error('--outer must be >=10, --inner >=99, and --workers >=1')
    if not (args.validate or args.applications or args.coverage):
        ap.error('Select --validate, --applications, and/or --coverage')
    if args.validate: validate_batch()
    if args.applications: application_checks()
    if args.coverage: run_coverage(args.outer,args.inner,args.workers)
if __name__=='__main__': main()
