#!/usr/bin/env python3
"""Source-aligned checks and refits requested by R1 M3 / R2 C2.

No outcome estimates enter first-stage fitting. Counts refer to controls only.
The original workbook is unchanged; all source-specific parameters and derived
contrasts are separate machine-readable revision outputs.
"""
from __future__ import annotations
import csv, json, math, sys
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm, lognorm, gamma
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'revision_analysis_bundle'))
sys.path.insert(0,str(ROOT/'original_release'/'IntervalDRMA'/'code'))
import radon_example_analysis as rad
import rsm_revision_remaining_analyses as old
from run_focused_revision import afo_inputs, summarize_fit, save_json, SEED
RESULTS=HERE/'results'; RESULTS.mkdir(exist_ok=True)


def grouped_fit(cuts, counts, initial):
    cuts=np.array(cuts,float); counts=np.array(counts,int)
    if len(counts)!=len(cuts)+1 or np.any(counts<=0): raise ValueError('Invalid categories')
    def probs(par):
        z=(np.log(cuts)-par[0])/np.exp(par[1])
        return np.r_[norm.cdf(z[0]), np.diff(norm.cdf(z)), norm.sf(z[-1])]
    def loss(par):
        p=probs(par)
        return 1e100 if np.any(p<=0) else -float(counts@np.log(p))
    x0=np.array([math.log(initial[0]),math.log(math.log(initial[1]))])
    fits=[minimize(loss,x0+np.array([shift,0.]),method='Nelder-Mead',options={'maxiter':3000,'xatol':1e-11,'fatol':1e-9}) for shift in [-.3,0.,.3]]
    fit=min(fits,key=lambda a:a.fun)
    if not fit.success: raise RuntimeError(fit.message)
    gm=math.exp(fit.x[0]); gsd=math.exp(math.exp(fit.x[1])); p=probs(fit.x)
    observed=counts/counts.sum()
    initial_p=np.diff(np.r_[0.,lognorm.cdf(cuts,s=math.log(initial[1]),scale=initial[0]),1.])
    return {'gm':gm,'gsd':gsd,'cutpoints_bq_m3':cuts.tolist(),'control_counts':counts.tolist(),
        'observed_probabilities':observed.tolist(),'historical_probabilities':initial_p.tolist(),'fitted_probabilities':p.tolist(),
        'probability_rmse':float(np.sqrt(np.mean((p-observed)**2))),'multinomial_deviance':float(2*np.sum(counts*np.log(observed/p))),
        'fit_method':'Multinomial grouped-control Lognormal maximum likelihood; no case counts, odds ratios, or CIs used.'}


def make_contrasts(categories,distributions,parameters=None,version='historical'):
    parameters=parameters or {}; out=[]
    for sid in dict.fromkeys(r['study_id'] for r in categories):
        block=[r for r in categories if r['study_id']==sid]; country=block[0]['country']; d={country:dict(distributions[country])}
        if sid in parameters: d[country][version]=(parameters[sid]['gm'],parameters[sid]['gsd'])
        out+=rad.build_contrasts(block,d,version)
    return out


def fit_radon(contrasts,rho=.5,bootstrap=0,seed=SEED+101):
    studies,xs,ys=rad.build_analysis_data(contrasts,rho)
    v=[]; z=[]
    for s,x,y in zip(studies,xs,ys):
        a=x@np.linalg.solve(s.sigma,x); v.append(1/a); z.append(x@np.linalg.solve(s.sigma,y)/a)
    f=summarize_fit(np.array(z),np.array(v),len(z),bootstrap=bootstrap,seed=seed,scale=100.)
    f['contrasts']=len(contrasts)
    residual=[]
    for s,x,y in zip(studies,xs,ys):
        V=s.sigma+f['tau']**2*np.outer(x,x); residual.extend(np.linalg.solve(np.linalg.cholesky(V),y-f['beta']*x).tolist())
    f['Q']=float(np.sum(np.square(residual))); f['max_abs_whitened_residual']=float(np.max(np.abs(residual)))
    f['CR2']=rad.cr2_slope_sensitivity(studies,xs,ys,f['beta'],f['tau'])
    return f


def radon_audit():
    cats,dist=rad.read_workbook(rad.DEFAULT_BOOK)
    # Alavanja: rounded pCi/L cutpoints (.79/.80 etc) joined at half-0.01 units.
    # Outer observed sample extrema are not treated as population truncation.
    specs={
      'Alavanja1994':{'cuts':np.array([.795,1.195,1.695,2.455])*37.,'counts':[233,242,233,252,223], 'country':'USA',
        'primary':True,'source':'Alavanja et al. (1994), Table 3 and footnote, p. 1833; doi:10.1093/jnci/86.24.1829',
        'url':'https://doi.org/10.1093/jnci/86.24.1829',
        'population':'1183 controls; individual time-weighted average exposure over years 5-30 before enrollment.',
        'decision':'Primary source-informed fit. The control sample and category-specific ORs match the reconstruction. Source pCi/L cutpoints are calibrated at their reporting precision; the existing Pavia half-Bq outcome supports remain unchanged.'},
      'Pershagen1994':{'cuts':[50.,80.,140.,400.],'counts':[952,561,568,436,59],'country':'Sweden',
        'primary':True,'source':'Pershagen et al. (1994), Table 3 footnote; doi:10.1056/NEJM199401203300302; author article reprinted in National Academies Environmental Medicine, chapter 51.',
        'url':'https://www.nationalacademies.org/read/4795/chapter/51',
        'population':'2576 controls with time-weighted exposure assigned to the five analytic categories; the full enrolled study had 2847 controls.',
        'decision':'Primary source-informed fit. Counts are from the analytic table underlying the reported ORs, not the larger enrollment count. The earlier mean 106.5 refers to residences and is not substituted for the individual time-weighted distribution.'},
      'Schoenberg1990':{'cuts':[37.,74.,148.],'counts':[324,66,10,2],'country':'USA',
        'primary':False,'source':'NJ Department of Health (1989), Technical Report Phase I, Table 6, printed p.67; 433 cases/402 controls.',
        'url':'https://dspace.njstatelib.org/server/api/core/bitstreams/5f1f5683-0a71-4f54-8c3a-d3d35301e6b0/content',
        'population':'402 controls in the preliminary Phase I report; index-residence year-long living-area measurements or estimates.',
        'decision':'Sensitivity only. The reconstruction reports 480 cases/442 controls and revised ORs, so this is not claimed to reconstruct its exact analytic exposure distribution.'}}
    fits={}
    for sid,a in specs.items():
        fits[sid]={**{k:v for k,v in a.items() if k not in ['cuts','counts']},**grouped_fit(a['cuts'],a['counts'],dist[a['country']]['historical'])}
    primarypar={sid:f for sid,f in fits.items() if f['primary']}
    primary=make_contrasts(cats,dist,primarypar); historical=make_contrasts(cats,dist)
    out={'source_control_fits':fits,'primary':fit_radon(primary,bootstrap=9999),'national_only':fit_radon(historical,bootstrap=9999,seed=SEED+102)}
    out['source_decisions']=[{'study_id':sid,'role':'primary' if a['primary'] else 'sensitivity only','source':a['source'],'population':a['population'],'reason':a['decision'],'url':a['url']} for sid,a in fits.items()]
    out['source_decisions'] += [
        {'study_id':'Blot1990','role':'national proxy in primary; mandatory mismatch sensitivity','source':'Blot et al. (1990), doi:10.1093/jnci/82.12.1025; Lubin and Boice (1997), Table 1.', 'population':'The available mean/median and tail summaries describe measured homes or an unspecified pooled case-control sample, not an identified control-only individual distribution.', 'reason':'Do not use outcome-selected pooled frequencies as a control distribution. A large national-versus-source discrepancy remains unresolved; report both source-summary substitution and omission sensitivities, rather than declaring the national model validated.'},
        {'study_id':'Pershagen1992','role':'national proxy in primary; dwelling-summary sensitivity','source':'Pershagen et al. (1992), PMID 1399616.', 'population':'127.7 arithmetic and 96.0 geometric means summarize 1573 residences of cases and two control series. Reconstructed ORs use individual average exposure and population controls.', 'reason':'The sampling unit and control population differ; household-distribution parameters are not an exact individual source-distribution estimate.'},
        {'study_id':'Darby1998','role':'national proxy in primary; pooled-category concordance only','source':'Darby et al. (2005), BMJ Table 2.', 'population':'Pooled European participants, not the UK-only study.', 'reason':'The five bounded categories can be compared and substituted as a sensitivity, but are not UK-study validation. The pooled 400-799 mean is not used for the reconstructed open >=400 category.'}]
    # Sensitivities deliberately keep all outcome data and half-unit supports unchanged.
    out['preliminary_NJ_controls_added']=fit_radon(make_contrasts(cats,dist,fits))
    oldpar={
      'Blot1990':(85.,math.exp(math.sqrt(2*math.log(118./85.)))),
      'Schoenberg1990':(22.,math.exp(math.sqrt(2*math.log(26./22.)))),
      'Pershagen1992':old._fit_lognormal_from_mean_tail(128.,threshold=150.,tail_p=.28,external_gsd=dist['Sweden']['historical'][1]),
      'Pershagen1994':old._fit_lognormal_from_mean_tail(107.,threshold=117.,tail_p=.25,external_gsd=dist['Sweden']['historical'][1]),
      'Alavanja1994':old._fit_lognormal_from_mean_tail(67.,threshold=148.,tail_p=.07,external_gsd=3.1)}
    def convert(p):
        return {sid:{'gm':a[0],'gsd':a[1]} for sid,a in p.items()}
    out['legacy_five_summary_sensitivity']=fit_radon(make_contrasts(cats,dist,convert(oldpar)))
    checkpar=primarypar|convert({k:oldpar[k] for k in ['Blot1990','Pershagen1992']})
    out['mismatched_summaries_added']=fit_radon(make_contrasts(cats,dist,checkpar))
    out['without_Blot']=fit_radon([r for r in primary if r['study_id']!='Blot1990'])
    out['rho_grid']={str(rho):fit_radon(primary,rho=rho) for rho in [0.,.25,.5,.75,.9]}
    # Updated external survey scenario retains the two usable control fits.
    out['external_2024_elsewhere']=fit_radon(make_contrasts(cats,dist,primarypar,version='2024'))
    out['assigned_value']={str(m):fit_radon(rad.build_contrasts(cats,dist,point_score_upper_multiplier=m)) for m in [1.2,1.5,2.]}
    pooled=[17.,39.,71.,136.,273.]; revised=[dict(r) for r in primary]; j=0
    for r in revised:
        if r['study_id']=='Darby1998':
            if j<4: r['comparison_mean']=pooled[j+1]
            r['reference_mean']=pooled[0]; r['x']=r['comparison_mean']-r['reference_mean']; j+=1
    out['Darby_pooled_bounded_means']=fit_radon(revised)
    out['leave_one_out']={sid:fit_radon([r for r in primary if r['study_id']!=sid]) for sid in dict.fromkeys(r['study_id'] for r in primary)}
    with (RESULTS/'radon_primary_contrasts.csv').open('w',newline='') as fh:
        w=csv.DictWriter(fh,fieldnames=list(primary[0]));w.writeheader();w.writerows(primary)
    save_json(RESULTS/'radon_source_audit.json',out)
    return out


def afo_probability_audit():
    import rsm_revision_sensitivity as rr
    rows,sp,x=afo_inputs(); records=[]; m=1/1609.344
    constraints=[
      ('Rasmussen','default',32509566,'PA',[3.],[8399/35269],0.),
      ('Smit 2014 nearest farm','nearest_farm',5,'Netherlands',np.array([280,440,640])*m,[.25,.5,.75],50*m),
      ('Smit 2014 swine','swine_buffer',5,'Netherlands',[500*m],[(7641+22542)/(22406+70142)],0.),
      ('Smit 2012 adult swine','presence of farm animals within 1 km',7,'Netherlands',[1000*m],[.824],0.),
      ('Freidl pig','pig_buffer',32507767,'Netherlands',np.array([500,1000,1500])*m,np.array([686,1925,2355])/2426,0.),
      ('Freidl goat','goat_distance',32507767,'Netherlands',np.array([1629,2478,3490])*m,[.25,.5,.75],0.),
      ('Freidl poultry','poultry_distance',32507767,'Netherlands',np.array([644,923,1296,2000])*m,[.25,.5,.75,2215/2426],0.),
      ('Post adult poultry','poultry_buffer',32509553,'Netherlands',np.array([500,1000,1500,2000])*m,[.1078,.4676,.7979,.9222],0.),
      ('Son CAFO','cafo_buffer',32511496,'NC',[15000*m],[1-348394/1195272],0.)]
    for study,group,sid,reg,cuts,p,lo in constraints:
        aa,ss=rr.REGION_PARAMS[reg]; ab,sb,_=sp[(sid,group)]
        def cdf(d,a,scale):
            f0=gamma.cdf(lo,a=a,scale=scale)
            return (gamma.cdf(d,a=a,scale=scale)-f0)/(1-f0)
        for cut,observed in zip(cuts,p):
            records.append({'study':study,'source_group':group,'threshold_miles':float(cut),
              'lower_truncation_miles':lo,'reported_cumulative_probability':float(observed),
              'regional_probability':float(cdf(cut,aa,ss)),'source_informed_probability':float(cdf(cut,ab,sb)),
              'regional_shape':aa,'regional_scale':ss,'source_shape':ab,'source_scale':sb})
    with (RESULTS/'afo_probability_audit.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    goat=[r for r in records if r['study']=='Freidl goat']
    quarter={'reported':[.25]*4,
       'original_regional':np.diff([0.]+[r['regional_probability'] for r in goat]+[1.]).tolist(),
       'source_informed':np.diff([0.]+[r['source_informed_probability'] for r in goat]+[1.]).tolist(),
       'cutpoints_m':[1629,2478,3490],
       'interpretation':'Whole-source-population quartile probabilities, including an unbounded final category. Mapping of finite outcome supports remains as separately recorded in the analysis workbook.'}
    save_json(RESULTS/'afo_probability_audit.json',{'cumulative_checks':records,'Freidl_goat_quartiles':quarter})
    return quarter


if __name__=='__main__':
    quarter=afo_probability_audit(); print(json.dumps(quarter,indent=2)); out=radon_audit(); print(json.dumps({k:v for k,v in out.items() if k in ['primary','national_only','mismatched_summaries_added','without_Blot']},indent=2))
