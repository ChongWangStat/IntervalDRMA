"""Deterministic checks for the final reviewer-directed revision.

Run: python -m unittest discover -s final_analysis -p 'test_revision.py' -v
"""
from pathlib import Path
import json, sys, unittest
import numpy as np
from scipy.stats import gamma
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from fast_reml_batch import fit_one
from run_focused_revision import afo_inputs,project_blocks
class FinalRevisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=json.loads((HERE/'results/application_checks.json').read_text())
        cls.rad=json.loads((HERE/'results/radon_source_audit.json').read_text())
        cls.cov=json.loads((HERE/'results/bootstrap_coverage.json').read_text())
    def test_rasmussen_mapping_applied(self):
        rows,sp,x=afo_inputs(); i=next(i for i,r in enumerate(rows) if r.refid==32509566)
        self.assertAlmostEqual(x[i],-5.91210,places=5)
    def test_current_afo_estimate(self):
        rows,sp,x=afo_inputs(); _,_,_,z,v,_=project_blocks(rows,x)
        b,t,se,q=fit_one(z,v)
        self.assertAlmostEqual(b,self.app['afo_main']['beta'],places=12)
        self.assertAlmostEqual(t,self.app['afo_main']['tau'],places=10)
    def test_exact_zero_boundary(self):
        b,t,se,q=fit_one(np.ones(8)*.03,np.ones(8)*.01)
        self.assertEqual(t,0.)
        self.assertAlmostEqual(b,.03)
    def test_solver_validation(self):
        d=json.loads((HERE/'results/solver_validation.json').read_text())
        self.assertEqual(d['datasets'],300);self.assertEqual(d['disagreements'],[])
        self.assertLess(max(d['max_abs_error_beta_tau_se']),d['tolerance'])
    def test_control_populations_not_pooled_cases(self):
        fs=self.rad['source_control_fits'];self.assertEqual(sum(fs['Alavanja1994']['control_counts']),1183)
        self.assertEqual(sum(fs['Pershagen1994']['control_counts']),2576)
        self.assertTrue(fs['Alavanja1994']['primary']);self.assertTrue(fs['Pershagen1994']['primary'])
        self.assertFalse(fs['Schoenberg1990']['primary'])
        for f in fs.values():
            self.assertAlmostEqual(sum(f['fitted_probabilities']),1.,places=12)
    def test_coverage_replicates(self):
        self.assertEqual(len(self.cov['conditions']),8)
        for c in self.cov['conditions']:
            self.assertEqual(c['outer'],1000);self.assertEqual(c['inner'],999)
            p=c['studentized']['coverage'];self.assertAlmostEqual(c['studentized']['mcse'],np.sqrt(p*(1-p)/1000),places=12)
    def test_current_application_bootstraps(self):
        for f in [self.app['afo_main'],self.app['Schultz_single_middle_point'],*self.app['afo_restrictions'].values(),self.rad['primary']]:
            self.assertEqual(f['bootstrap_replicates'],9999)
            lo,hi=f['OR_intervals']['studentized_bootstrap'];self.assertLess(lo,hi)
    def test_paired_bound_grid(self):
        self.assertEqual(len(self.app['paired_dmax']),6)
        for m in [.8,1.,1.2]:
            rs=[r for r in self.app['paired_dmax'] if r['multiplier']==m]
            self.assertEqual({r['scoring'] for r in rs},{'conditional_mean','finite_midpoint'})
    def test_freidl_probabilities(self):
        d=json.loads((HERE/'results/afo_probability_audit.json').read_text())['Freidl_goat_quartiles']
        self.assertGreater(d['original_regional'][0],.88)
        self.assertLess(max(abs(x-.25) for x in d['source_informed']),.011)
    def test_schultz_information(self):
        a=self.app['afo_main']['Schultz_information_fraction'];b=self.app['Schultz_single_middle_point']['Schultz_information_fraction']
        self.assertTrue(0<b<a<1)
    def test_current_adjusted_or_run(self):
        current=json.loads((HERE/'results/adjusted_or_current.json').read_text())
        repeated=json.loads((HERE/'results/archive_verification/adjusted_regenerated.json').read_text())
        self.assertEqual(current,repeated)
        self.assertEqual(len(current),4)
        self.assertAlmostEqual(current['common_adequate']['mean_beta'],-0.065225228,places=8)
    def test_nonlinear_uses_full_covariance(self):
        f=self.app['nonlinear']; V=np.array(f['coefficient_covariance'])
        self.assertTrue(np.all(np.linalg.eigvalsh(V)>0))
        for r in f['point_comparisons']:
            z=np.array([r['comparison']-r['reference'],np.log1p(r['comparison'])-np.log1p(r['reference'])])
            se=np.sqrt(z@V@z);lo,hi=r['nonlinear_normal_CI']
            self.assertAlmostEqual(np.log(hi)-np.log(lo),3.92*se,places=7)
if __name__=='__main__': unittest.main()
