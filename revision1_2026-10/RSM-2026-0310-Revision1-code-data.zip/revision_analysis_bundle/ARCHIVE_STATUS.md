# Historical/intermediate revision files

See ../README_REPRODUCE.md for current commands and output precedence.
This directory contains retained checkpoints and portable copies of the earlier
scripts. The original ZIP beside this directory is byte-unchanged. The current
application and expanded-bootstrap outputs are in ../final_analysis/results/.
The current adjusted-OR output is adjusted_or_current.json in that directory;
the paired500 checkpoint here is retained only as history. The old prototype
rsm_revision_final_simulations.py is not the current manuscript entry point.
