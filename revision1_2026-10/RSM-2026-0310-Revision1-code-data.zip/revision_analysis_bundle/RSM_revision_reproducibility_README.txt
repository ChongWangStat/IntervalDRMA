RSM-2026-0310 reviewer-revision analysis files
Final Revision 1 checkpoint: 6 October 2026

CORE REVISION APPLICATION SCRIPT
  rsm_revision_sensitivity.py
    - reproduces submitted/historical AFO baseline analyses
    - M2 nonexchangeable working-correlation sensitivities
    - M3 source-informed Gamma calibration and row-level mapping audit
    - M4 conventional assigned-value/open-category comparisons
    - M4 +/-20% finite-upper-bound sensitivity under the proposed mapping
    - M4 nonlinear log(1+D) sensitivity
    - M4 adjusted-OR verification implementation

REVIEWER-DRIVEN REMAINING-ANALYSES SCRIPT
  rsm_revision_remaining_analyses.py
    - radon first-stage plausibility checks
    - targeted studentized parametric-bootstrap repeated-sampling coverage experiment
    - 64-cell generic fractional-factorial simulation

ADDITIONAL/ARCHIVED SIMULATION SCRIPTS
  run_m2_sim.py
    - structured-correlation misspecification Monte Carlo check
  rsm_revision_final_simulations.py
    - reproducible driver used for archived M2/M4 verification runs

FINAL MACHINE-READABLE OUTPUTS
  rsm_revision_sensitivity_results_consolidated.json
  rsm_revision_m3_row_mapping.csv
  rsm_adjusted_or_sim_paired500.json
  rsm_m2_structured_corr_sim.json
  rsm_radon_first_stage_plausibility_final.json
  rsm_radon_first_stage_plausibility.csv
  rsm_bootstrap_coverage_final.json
  rsm_factorial_final.json
  rsm_generic_factorial_cells.csv
  rsm_revision_remaining_analyses_final.json

INPUT USED FOR REVISION ANALYSES
  Observed Data.xlsx

REPLICATE COUNTS AND SCOPE
- M2 structured-correlation verification: 500 completed replicates per structure.
- M4 adjusted-OR verification: 500 completed replicates per condition.
- Studentized-bootstrap coverage: 200 outer replicates per K (K=10,20,30),
  199 inner parametric-bootstrap replicates per outer fit.
- Generic factorial: 64 cells, 500 completed replicates per cell.
- Historical 5,000-replicate empirical simulations are separate analyses and are
  not relabeled as these reviewer-driven experiments.

RADON PLAUSIBILITY CHECK
The bounded-category comparison uses only five exactly matching Darby categories.
The published 400-799 Bq/m3 mean is not substituted for the reconstructed >=400
support. A second five-study sensitivity uses early-study exposure summaries; source
samples/definitions are not identical to the Pavia extraction, so this is a plausibility
sensitivity rather than exact source-population reconstruction.

FINAL-VS-ATTEMPTED FILES
The files named *_final.json and rsm_generic_factorial_cells.csv are the final outputs
used in the manuscript. Intermediate stdout/timing files from abandoned larger
bootstrap attempts are diagnostic only and are not included in the clean final
submission package.
