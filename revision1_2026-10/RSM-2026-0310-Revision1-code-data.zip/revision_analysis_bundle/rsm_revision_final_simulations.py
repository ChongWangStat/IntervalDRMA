#!/usr/bin/env python3
"""Final/revision Monte Carlo checks for RSM reviewer responses.

Reuses the deterministic revision-analysis code in rsm_revision_sensitivity.py.
Outputs:
  - M2 structured-correlation misspecification simulation (default R=5000)
  - M4 adjusted-OR simulation (default R=5000)
This file is kept separately for reproducibility and does not edit the manuscript.
"""
from __future__ import annotations
import argparse, json, math, sys
from pathlib import Path
import numpy as np
from scipy.stats import t as student_t

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import rsm_revision_sensitivity as rr


def m2_structured_sim(R=5000, seed=20261002):
    rows=rr.read_rows(); sp=rr.source_params(rows); x=rr.design(rows,sp,use_source=True)
    true_fit=rr.fit_reml(rows,x,corr_kind='exchangeable',rho=.5)
    beta=true_fit['beta'][0]; tau=true_fit['tau']; K=true_fit['K']
    rng=np.random.default_rng(seed)
    out={}
    # Analysis deliberately uses exchangeable rho=.5 while data are generated from structured matrices.
    fit_blocks=rr.cov_blocks(rows,'exchangeable',.5)
    y0=np.array([r.y for r in rows])
    study_ix=[ix for _,ix,_,_ in fit_blocks]
    tc=student_t.ppf(.975,K-1)
    for kind in ['structured_moderate','structured_strong']:
        true_blocks=rr.cov_blocks(rows,kind,.5)
        chols=[np.linalg.cholesky(S) for _,_,S,_ in true_blocks]
        est=np.empty(R); taus=np.empty(R); ses=np.empty(R)
        for rep in range(R):
            bstudy=rng.normal(0,tau,size=K)
            ysim=np.empty(len(rows))
            for k,((_,ix,_,_),L) in enumerate(zip(true_blocks,chols)):
                ysim[ix]=(beta+bstudy[k])*x[ix]+L@rng.normal(size=len(ix))
            # Fit the same random-slope REML but with exchangeable rho=.5.
            # Rebuild tiny block arrays and use rr.fit_meta_arrays, whose covariance blocks are treated fixed.
            yb=[ysim[ix] for ix in study_ix]
            Sb=[S for _,_,S,_ in fit_blocks]
            xb=[x[ix] for ix in study_ix]
            bh,th,seh=rr.fit_meta_arrays(yb,Sb,xb)
            est[rep]=bh; taus[rep]=th; ses[rep]=seh
        z=(est-beta)/ses
        out[kind]={
          'R':R,'beta_true':beta,'tau_true':tau,
          'mean_beta':float(est.mean()),'bias':float(est.mean()-beta),
          'rmse':float(np.sqrt(np.mean((est-beta)**2))),
          'mean_tau':float(taus.mean()),'mean_se':float(ses.mean()),
          'normal_coverage':float(np.mean(np.abs(z)<=1.96)),
          't_coverage':float(np.mean(np.abs(z)<=tc)),
        }
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--replicates',type=int,default=5000)
    ap.add_argument('--adjusted-n',type=int,default=1500)
    ap.add_argument('--output',type=Path,default=HERE/'rsm_revision_final_simulations.json')
    args=ap.parse_args()
    out={
      'm2_structured_correlation_simulation':m2_structured_sim(R=args.replicates),
      'm4_adjusted_or_simulation':rr.adjusted_or_sim(R=args.replicates,n=args.adjusted_n),
    }
    args.output.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
