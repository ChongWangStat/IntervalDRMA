#!/usr/bin/env python3
"""Remaining reviewer-driven analyses for RSM-2026-0310 Revision 1.

Analyses added after the first revision checkpoint:
1. Repeated-sampling coverage of the studentized parametric-bootstrap interval
   at K=10,20,30 using the revised source-informed AFO support mapping.
2. A generic 2^(8-2) resolution-IV fractional factorial simulation varying study count, contrasts/study,
   interval width, exposure skewness, point-support proportion, within-study
   correlation magnitude, correlation structure, and dose-response curvature.
3. Radon first-stage plausibility checks against published exposure summaries,
   including a category-mean concordance check and two source-informed
   sensitivity analyses.

The script writes only new outputs; it does not modify the archived revision
bundle or original-release files.
"""
from __future__ import annotations

import itertools
import json
import math
import os
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
from scipy.stats import gamma, norm, t as student_t

HERE = Path(__file__).resolve().parent
REVROOT = HERE.parent
ORIG = REVROOT / "original_release" / "IntervalDRMA"
ORIG_CODE = ORIG / "code"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(ORIG_CODE) not in sys.path:
    sys.path.insert(0, str(ORIG_CODE))

import rsm_revision_sensitivity as rr
from interval_drma_core import FastReml, Study
from radon_example_analysis import (
    read_workbook as read_radon_workbook,
    build_contrasts as build_radon_contrasts,
    fit_contrasts as fit_radon_contrasts,
    lognormal_conditional_mean,
)

OUT_JSON = HERE / "rsm_revision_remaining_analyses.json"
OUT_FACTOR_CSV = HERE / "rsm_generic_factorial_cells.csv"
OUT_RADON_CSV = HERE / "rsm_radon_first_stage_plausibility.csv"


def complete_afo_blocks():
    rows = rr.read_rows(HERE / "Observed Data.xlsx")
    sp = rr.source_params(rows)
    # Correct the archived Rasmussen lookup mismatch without changing the archive.
    rasm = next(r for r in rows if r.refid == 32509566)
    sp[(rasm.refid, rr.row_group(rasm))] = sp[(32509566, "default")]
    x = rr.design(rows, sp, use_source=True)
    fit = rr.fit_reml(rows, x, corr_kind="exchangeable", rho=0.5)
    base = []
    for rid, ix, S, _ in rr.cov_blocks(rows, "exchangeable", 0.5):
        base.append((Study(int(rid), [], np.asarray(S, float)), np.asarray(x[ix], float)))
    return base, float(fit["beta"][0]), float(fit["tau"])


def bootstrap_cell(k: int, outer_reps: int = 200, inner_reps: int = 199,
                   templates: int = 25, seed: int = 202610061):
    base, beta_true, tau_true = complete_afo_blocks()
    rng = np.random.default_rng(seed + 1000 * k)
    sizes = np.full(templates, outer_reps // templates, dtype=int)
    sizes[: outer_reps % templates] += 1
    normal_cov = []
    t_cov = []
    boot_cov = []
    basic_cov = []
    normal_width = []
    t_width = []
    boot_width = []
    basic_width = []
    tau_zero = []
    boot_tau_zero = []

    for n_this in sizes:
        pick = rng.choice(len(base), size=k, replace=True)
        studies = [base[i][0] for i in pick]
        x = [base[i][1] for i in pick]
        fitter = FastReml(studies, x)
        chol = [np.linalg.cholesky(s.sigma) for s in studies]
        tcrit = float(student_t.ppf(0.975, k - 1))
        for _ in range(int(n_this)):
            bstudy = rng.normal(0.0, tau_true, size=k)
            y = [
                (beta_true + bstudy[j]) * x[j]
                + chol[j] @ rng.normal(size=len(x[j]))
                for j in range(k)
            ]
            fit = fitter.fit_detailed(y)
            bh = float(fit["beta"])
            th = float(fit["tau"])
            seh = float(fit["se_beta"])
            tau_zero.append(th == 0.0)
            nlo, nhi = bh - 1.96 * seh, bh + 1.96 * seh
            tlo, thi = bh - tcrit * seh, bh + tcrit * seh
            normal_cov.append(nlo <= beta_true <= nhi)
            t_cov.append(tlo <= beta_true <= thi)
            normal_width.append(nhi - nlo)
            t_width.append(thi - tlo)

            # Parametric bootstrap conditional on the fitted support means/covariances.
            bboot = np.empty(inner_reps)
            sboot = np.empty(inner_reps)
            zboot = 0
            for b in range(inner_reps):
                rs = rng.normal(0.0, th, size=k)
                yb = [
                    (bh + rs[j]) * x[j]
                    + chol[j] @ rng.normal(size=len(x[j]))
                    for j in range(k)
                ]
                bb, tt = fitter.fit(yb)
                ss = fitter.standard_error(tt)
                bboot[b] = bb
                sboot[b] = (bb - bh) / ss
                zboot += int(tt == 0.0)
            qbeta = np.quantile(bboot, [0.025, 0.975])
            qstud = np.quantile(sboot, [0.025, 0.975])
            blo, bhi = 2 * bh - qbeta[1], 2 * bh - qbeta[0]
            slo, shi = bh - qstud[1] * seh, bh - qstud[0] * seh
            basic_cov.append(blo <= beta_true <= bhi)
            boot_cov.append(slo <= beta_true <= shi)
            basic_width.append(bhi - blo)
            boot_width.append(shi - slo)
            boot_tau_zero.append(zboot / inner_reps)

    def prop(x):
        p = float(np.mean(x)); n = len(x)
        return p, math.sqrt(p * (1 - p) / n)

    nc, nmc = prop(normal_cov)
    tc, tmc = prop(t_cov)
    sc, smc = prop(boot_cov)
    bc, bmc = prop(basic_cov)
    return {
        "K": k,
        "outer_replicates": len(normal_cov),
        "bootstrap_replicates_per_outer_fit": inner_reps,
        "templates": templates,
        "beta_true": beta_true,
        "tau_true": tau_true,
        "normal_coverage": nc,
        "normal_coverage_mcse": nmc,
        "study_t_coverage": tc,
        "study_t_coverage_mcse": tmc,
        "studentized_bootstrap_coverage": sc,
        "studentized_bootstrap_coverage_mcse": smc,
        "basic_bootstrap_coverage": bc,
        "basic_bootstrap_coverage_mcse": bmc,
        "normal_mean_width": float(np.mean(normal_width)),
        "study_t_mean_width": float(np.mean(t_width)),
        "studentized_bootstrap_mean_width": float(np.mean(boot_width)),
        "basic_bootstrap_mean_width": float(np.mean(basic_width)),
        "outer_tau_zero_rate": float(np.mean(tau_zero)),
        "mean_inner_bootstrap_tau_zero_rate": float(np.mean(boot_tau_zero)),
        "design": "complete source-informed AFO mapping; empirical study blocks resampled with replacement",
    }


def run_bootstrap_coverage(outer_reps=200, inner_reps=199):
    """Run K=10,20,30 cells with five independent chunks per K.

    Splitting each K cell across chunks uses all available CPU cores while
    preserving 25 resampled empirical support/covariance templates per K.
    """
    n_chunks = 5
    counts = np.full(n_chunks, outer_reps // n_chunks, dtype=int)
    counts[: outer_reps % n_chunks] += 1
    chunks = {str(k): [] for k in (10, 20, 30)}
    max_workers = min(5, os.cpu_count() or 1)
    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        futs = {}
        for k in (10, 20, 30):
            for c, n_outer in enumerate(counts):
                if int(n_outer) == 0:
                    continue
                seed = 202610061 + 100000 * k + 1000 * c
                fut = ex.submit(bootstrap_cell, k, int(n_outer), inner_reps, 5, seed)
                futs[fut] = (k, c)
        for fut in as_completed(futs):
            k, _ = futs[fut]
            chunks[str(k)].append(fut.result())

    coverage_keys = [
        "normal_coverage", "study_t_coverage",
        "studentized_bootstrap_coverage", "basic_bootstrap_coverage",
    ]
    mean_keys = [
        "normal_mean_width", "study_t_mean_width",
        "studentized_bootstrap_mean_width", "basic_bootstrap_mean_width",
        "outer_tau_zero_rate", "mean_inner_bootstrap_tau_zero_rate",
    ]
    out = {}
    for k in (10, 20, 30):
        parts = chunks[str(k)]
        n = sum(int(z["outer_replicates"]) for z in parts)
        row = {
            "K": k,
            "outer_replicates": n,
            "bootstrap_replicates_per_outer_fit": inner_reps,
            "templates": sum(int(z["templates"]) for z in parts),
            "beta_true": float(parts[0]["beta_true"]),
            "tau_true": float(parts[0]["tau_true"]),
            "design": "complete source-informed AFO mapping; empirical study blocks resampled with replacement",
        }
        for key in coverage_keys:
            p = sum(float(z[key]) * int(z["outer_replicates"]) for z in parts) / n
            row[key] = p
            row[key + "_mcse"] = math.sqrt(p * (1.0 - p) / n)
        for key in mean_keys:
            row[key] = sum(float(z[key]) * int(z["outer_replicates"]) for z in parts) / n
        out[str(k)] = row
    return out


# ---------- Generic factorial ----------

def gamma_interval_moment(lo, hi, shape, scale, q=1):
    if lo == hi:
        return lo ** q
    den = gamma.cdf(hi, a=shape, scale=scale) - gamma.cdf(lo, a=shape, scale=scale)
    coef = (scale ** q) * math.exp(math.lgamma(shape + q) - math.lgamma(shape))
    num = gamma.cdf(hi, a=shape + q, scale=scale) - gamma.cdf(lo, a=shape + q, scale=scale)
    return coef * num / den


def generic_supports(m, width, exact_prop, study_index):
    # Observation-specific comparison and reference supports with mild study jitter.
    refs = np.linspace(0.9, 2.1, m)
    comps = refs + np.linspace(1.8, 4.2, m)
    jitter = 0.08 * ((study_index % 5) - 2)
    n_exact = int(round(exact_prop * m))
    out = []
    for j in range(m):
        rb = max(0.08, refs[j] + 0.5 * jitter)
        cb = max(rb + 0.5, comps[j] + jitter)
        if j < n_exact:
            B = (rb, rb)
            A = (cb, cb)
        else:
            B = (max(0.02, rb - width / 2), rb + width / 2)
            A = (max(0.02, cb - width / 2), cb + width / 2)
        out.append((A, B))
    return out


def corr_generic(m, rho, structure):
    if m == 1:
        return np.ones((1, 1))
    if structure == "exchangeable":
        C = np.full((m, m), rho, float)
        np.fill_diagonal(C, 1.0)
        return C
    # PSD two-cluster structure: stronger dependence within related contrasts,
    # weaker dependence across the two clusters.
    low = max(0.02, rho - 0.20)
    high = min(0.95, rho + 0.20)
    g = np.zeros((m, 2))
    split = int(math.ceil(m / 2))
    g[:split, 0] = 1.0
    g[split:, 1] = 1.0
    C = low * np.ones((m, m)) + (high - low) * (g @ g.T) + (1.0 - high) * np.eye(m)
    return C


def generic_factorial_cell(cell_id, factors, replicates=500, seed=202610062):
    K = factors["K"]
    m = factors["m"]
    width = factors["width"]
    shape = factors["shape"]
    exact = factors["exact"]
    rho = factors["rho"]
    structure = factors["structure"]
    curvature = factors["curvature"]
    scale = 5.0 / shape  # fix the marginal Gamma mean at 5
    beta_true = -0.08
    tau_true = 0.06
    rng = np.random.default_rng(seed + cell_id * 7919)

    studies = []
    x_true = []
    x_mid = []
    x_quad = []
    chols = []
    for k in range(K):
        pairs = generic_supports(m, width, exact, k)
        xt, xm, xq = [], [], []
        for A, B in pairs:
            ma = gamma_interval_moment(*A, shape, scale, q=1)
            mb = gamma_interval_moment(*B, shape, scale, q=1)
            qa = gamma_interval_moment(*A, shape, scale, q=2) / 25.0
            qb = gamma_interval_moment(*B, shape, scale, q=2) / 25.0
            xt.append(ma - mb)
            xm.append(0.5 * (A[0] + A[1]) - 0.5 * (B[0] + B[1]))
            xq.append(qa - qb)
        xt = np.asarray(xt); xm = np.asarray(xm); xq = np.asarray(xq)
        se = 0.13 + 0.015 * np.arange(m) + 0.004 * (k % 3)
        C = corr_generic(m, rho, structure)
        S = np.diag(se) @ C @ np.diag(se)
        studies.append(Study(k + 1, [], S))
        x_true.append(xt); x_mid.append(xm); x_quad.append(xq)
        chols.append(np.linalg.cholesky(S))

    fit_true = FastReml(studies, x_true)
    fit_mid = FastReml(studies, x_mid)
    est_true = np.empty(replicates); se_true = np.empty(replicates)
    est_mid = np.empty(replicates); se_mid = np.empty(replicates)
    tau_true_hat = np.empty(replicates); tau_mid_hat = np.empty(replicates)
    for r in range(replicates):
        bs = rng.normal(0.0, tau_true, size=K)
        y = []
        for k in range(K):
            mean = (beta_true + bs[k]) * x_true[k] + curvature * x_quad[k]
            y.append(mean + chols[k] @ rng.normal(size=m))
        b1, t1 = fit_true.fit(y); s1 = fit_true.standard_error(t1)
        b2, t2 = fit_mid.fit(y); s2 = fit_mid.standard_error(t2)
        est_true[r], tau_true_hat[r], se_true[r] = b1, t1, s1
        est_mid[r], tau_mid_hat[r], se_mid[r] = b2, t2, s2

    def summ(est, se, tauhat):
        err = est - beta_true
        d = {
            "mean_beta": float(np.mean(est)),
            "error_vs_generating_linear_beta": float(np.mean(err)),
            "abs_error_vs_generating_linear_beta": float(abs(np.mean(err))),
            "rmse_vs_generating_linear_beta": float(np.sqrt(np.mean(err ** 2))),
            "mean_se": float(np.mean(se)),
            "mean_tau": float(np.mean(tauhat)),
        }
        if curvature == 0.0:
            crit = float(student_t.ppf(0.975, K - 1))
            d["normal_coverage"] = float(np.mean(np.abs(err) <= 1.96 * se))
            d["study_t_coverage"] = float(np.mean(np.abs(err) <= crit * se))
        else:
            d["normal_coverage"] = None
            d["study_t_coverage"] = None
        return d

    return {
        "cell_id": cell_id,
        **factors,
        "replicates": replicates,
        "beta_generating_linear_component": beta_true,
        "tau_true": tau_true,
        "proposed": summ(est_true, se_true, tau_true_hat),
        "midpoint": summ(est_mid, se_mid, tau_mid_hat),
    }


def run_generic_factorial(replicates=500):
    """Run a balanced 2^(8-2) resolution-IV fractional factorial (64 cells).

    Six factors are enumerated directly and two are generated as three-factor
    products.  Hence each main effect is aliased only with interactions of order
    three or higher, which is appropriate for the reviewer-requested compact
    screen of generic design features.
    """
    levels = {
        "K": [10, 30],
        "m": [2, 5],
        "width": [1.0, 4.0],
        "shape": [4.0, 1.25],  # larger -> less skew; smaller -> strong skew
        "exact": [0.0, 0.4],
        "rho": [0.2, 0.7],
        "structure": ["exchangeable", "clustered"],
        "curvature": [0.0, 0.04],
    }
    # Base signs A-F enumerate a full 2^6 design.  G=ABC and H=ADE.
    combos = []
    for signs in itertools.product((-1, 1), repeat=6):
        A, B, C, D, E, F = signs
        G = A * B * C
        H = A * D * E
        combos.append({
            "K": 10 if A < 0 else 30,
            "m": 2 if B < 0 else 5,
            "width": 1.0 if C < 0 else 4.0,
            "shape": 4.0 if D < 0 else 1.25,
            "exact": 0.0 if E < 0 else 0.4,
            "rho": 0.2 if F < 0 else 0.7,
            "structure": "exchangeable" if G < 0 else "clustered",
            "curvature": 0.0 if H < 0 else 0.04,
        })
    keys = list(levels)
    cells = [None] * len(combos)
    workers = min(8, os.cpu_count() or 2)
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs = {
            ex.submit(generic_factorial_cell, i, f, replicates, 202610062): i
            for i, f in enumerate(combos)
        }
        for fut in as_completed(futs):
            cells[futs[fut]] = fut.result()

    factor_summary = {}
    for factor in keys[:-1]:
        factor_summary[factor] = {}
        for level in levels[factor]:
            sub_lin = [c for c in cells if c[factor] == level and c["curvature"] == 0.0]
            sub_curv = [c for c in cells if c[factor] == level and c["curvature"] != 0.0]
            factor_summary[factor][str(level)] = {
                "linear_proposed_mean_abs_bias": float(np.mean([c["proposed"]["abs_error_vs_generating_linear_beta"] for c in sub_lin])),
                "linear_midpoint_mean_abs_bias": float(np.mean([c["midpoint"]["abs_error_vs_generating_linear_beta"] for c in sub_lin])),
                "linear_proposed_mean_rmse": float(np.mean([c["proposed"]["rmse_vs_generating_linear_beta"] for c in sub_lin])),
                "linear_midpoint_mean_rmse": float(np.mean([c["midpoint"]["rmse_vs_generating_linear_beta"] for c in sub_lin])),
                "linear_proposed_mean_normal_coverage": float(np.mean([c["proposed"]["normal_coverage"] for c in sub_lin])),
                "linear_proposed_mean_t_coverage": float(np.mean([c["proposed"]["study_t_coverage"] for c in sub_lin])),
                "curved_proposed_mean_abs_deviation_from_linear_component": float(np.mean([c["proposed"]["abs_error_vs_generating_linear_beta"] for c in sub_curv])),
                "curved_midpoint_mean_abs_deviation_from_linear_component": float(np.mean([c["midpoint"]["abs_error_vs_generating_linear_beta"] for c in sub_curv])),
            }

    linear_cells = [c for c in cells if c["curvature"] == 0.0]
    curved_cells = [c for c in cells if c["curvature"] != 0.0]
    overall = {
        "design": "2^(8-2) resolution-IV fractional factorial; G=A*B*C, H=A*D*E",
        "n_cells": len(cells),
        "replicates_per_cell": replicates,
        "linear_cells": len(linear_cells),
        "curved_cells": len(curved_cells),
        "linear_proposed_max_abs_bias": float(max(c["proposed"]["abs_error_vs_generating_linear_beta"] for c in linear_cells)),
        "linear_midpoint_max_abs_bias": float(max(c["midpoint"]["abs_error_vs_generating_linear_beta"] for c in linear_cells)),
        "linear_proposed_mean_normal_coverage": float(np.mean([c["proposed"]["normal_coverage"] for c in linear_cells])),
        "linear_proposed_mean_t_coverage": float(np.mean([c["proposed"]["study_t_coverage"] for c in linear_cells])),
        "curved_proposed_mean_abs_deviation_from_linear_component": float(np.mean([c["proposed"]["abs_error_vs_generating_linear_beta"] for c in curved_cells])),
        "curved_midpoint_mean_abs_deviation_from_linear_component": float(np.mean([c["midpoint"]["abs_error_vs_generating_linear_beta"] for c in curved_cells])),
    }

    import csv
    with OUT_FACTOR_CSV.open("w", newline="", encoding="utf-8") as fh:
        fields = keys + [
            "cell_id", "replicates",
            "proposed_mean_beta", "proposed_bias", "proposed_rmse", "proposed_normal_coverage", "proposed_t_coverage",
            "midpoint_mean_beta", "midpoint_bias", "midpoint_rmse", "midpoint_normal_coverage", "midpoint_t_coverage",
        ]
        w = csv.DictWriter(fh, fieldnames=fields); w.writeheader()
        for c in cells:
            w.writerow({
                **{k: c[k] for k in keys}, "cell_id": c["cell_id"], "replicates": c["replicates"],
                "proposed_mean_beta": c["proposed"]["mean_beta"],
                "proposed_bias": c["proposed"]["error_vs_generating_linear_beta"],
                "proposed_rmse": c["proposed"]["rmse_vs_generating_linear_beta"],
                "proposed_normal_coverage": c["proposed"]["normal_coverage"],
                "proposed_t_coverage": c["proposed"]["study_t_coverage"],
                "midpoint_mean_beta": c["midpoint"]["mean_beta"],
                "midpoint_bias": c["midpoint"]["error_vs_generating_linear_beta"],
                "midpoint_rmse": c["midpoint"]["rmse_vs_generating_linear_beta"],
                "midpoint_normal_coverage": c["midpoint"]["normal_coverage"],
                "midpoint_t_coverage": c["midpoint"]["study_t_coverage"],
            })
    return {"design_levels": levels, "overall": overall, "factor_summary": factor_summary, "cells": cells}


# ---------- Radon first-stage plausibility ----------

def _fit_lognormal_from_mean_tail(mean, threshold, tail_p, external_gsd):
    q = float(norm.ppf(1.0 - tail_p))
    disc = (2 * q) ** 2 - 8 * math.log(threshold / mean)
    if disc < 0:
        raise ValueError("No real Lognormal solution for mean+tail constraints")
    roots = [s for s in ((2 * q + math.sqrt(disc)) / 2, (2 * q - math.sqrt(disc)) / 2) if s > 0]
    sigma0 = math.log(external_gsd)
    sigma = min(roots, key=lambda s: abs(s - sigma0))
    mu = math.log(threshold) - q * sigma
    return math.exp(mu), math.exp(sigma)


def radon_first_stage_plausibility():
    book = ORIG / "data" / "radon_lung_cancer_contrasts.xlsx"
    categories, distributions = read_radon_workbook(book)
    base = build_radon_contrasts(categories, distributions, "historical")
    base_fit = fit_radon_contrasts(base, rho=0.5)["random_effects"]

    # Darby et al. 2005 pooled European individual-data analysis (Table 2):
    # measured category means in the same standard bins.
    # Table 2 uses a separate 400--799 and >=800 split, whereas the
    # reconstructed Darby1998 study uses a single >=400 support.  We therefore
    # restrict the direct mean comparison to the five exactly matching bounded
    # categories rather than treating 542 Bq/m^3 (the 400--799 mean) as the
    # mean of the wider >=400 support.
    darby_observed = {
        "<25": 17.0, "25-49": 39.0, "50-99": 71.0,
        "100-199": 136.0, "200-399": 273.0,
    }
    darby_rows = [r for r in categories if str(r["study_id"]) == "Darby1998"]
    darby_check = []
    for r in darby_rows:
        lo = float(r["lower_bq_m3"])
        hi = math.inf if bool(r["open_upper"]) else float(r["upper_bq_m3"])
        gm, gsd = distributions["UK"]["historical"]
        mapped = lognormal_conditional_mean(lo, hi, gm, gsd)
        level = str(r["reported_level"])
        if level not in darby_observed:
            continue
        observed = darby_observed[level]
        darby_check.append({
            "study": "Darby1998", "category": str(r["reported_level"]),
            "published_pooled_measured_mean": observed,
            "historical_UK_lognormal_conditional_mean": mapped,
            "percent_difference": 100.0 * (mapped - observed) / observed,
        })

    # Sensitivity: replace all Darby1998 support representatives with the published
    # pooled measured category means.  This is deliberately labeled a concordance
    # sensitivity rather than a source-population reconstruction.
    darby_override = []
    for r in base:
        q = dict(r)
        if r["study_id"] == "Darby1998":
            if r["comparison_level"] in darby_observed:
                q["comparison_mean"] = darby_observed[r["comparison_level"]]
            if r["reference_level"] in darby_observed:
                q["reference_mean"] = darby_observed[r["reference_level"]]
            q["x"] = q["comparison_mean"] - q["reference_mean"]
        darby_override.append(q)
    darby_fit = fit_radon_contrasts(darby_override, rho=0.5)["random_effects"]

    # Lubin & Boice 1997 Table 1 supplied overall study-exposure summaries for
    # several early studies that also appear in Pavia.  Sample definitions are
    # not perfectly identical to Pavia's extraction, so these are plausibility
    # checks/sensitivities, not exact source-population validation.
    source_summary = {
        "Blot1990": {"country": "China", "mean": 118.0, "median": 85.0, "tail_threshold": 148.0, "tail_p": 0.20},
        "Schoenberg1990": {"country": "USA", "mean": 26.0, "median": 22.0, "tail_threshold": 148.0, "tail_p": 0.01},
        "Pershagen1992": {"country": "Sweden", "mean": 128.0, "tail_threshold": 150.0, "tail_p": 0.28},
        "Pershagen1994": {"country": "Sweden", "mean": 107.0, "tail_threshold": 117.0, "tail_p": 0.25},
        "Alavanja1994": {"country": "USA", "mean": 67.0, "tail_threshold": 148.0, "tail_p": 0.07},
    }
    study_params = {}
    study_checks = []
    for sid, s in source_summary.items():
        gm0, gsd0 = distributions[s["country"]]["historical"]
        sig0 = math.log(gsd0)
        ext_mean = math.exp(math.log(gm0) + sig0 ** 2 / 2)
        ext_tail = 1.0 - norm.cdf((math.log(s["tail_threshold"]) - math.log(gm0)) / sig0)
        if "median" in s:
            gm = s["median"]
            sigma = math.sqrt(2.0 * math.log(s["mean"] / s["median"]))
            gsd = math.exp(sigma)
            fit_basis = "published mean+median"
        else:
            gm, gsd = _fit_lognormal_from_mean_tail(s["mean"], s["tail_threshold"], s["tail_p"], gsd0)
            fit_basis = "published mean+tail probability; root nearest external GSD"
        study_params[sid] = (gm, gsd)
        study_checks.append({
            "study": sid, "country": s["country"],
            "published_mean": s["mean"], "published_median": s.get("median"),
            "published_tail_threshold": s["tail_threshold"], "published_tail_probability": s["tail_p"],
            "external_gm": gm0, "external_gsd": gsd0, "external_implied_mean": ext_mean,
            "external_implied_tail_probability": ext_tail,
            "source_informed_gm": gm, "source_informed_gsd": gsd, "source_informed_basis": fit_basis,
        })

    # Build radon contrasts using these source-informed parameters for the five
    # matched early studies and historical country parameters elsewhere.
    source_contrasts = []
    ids = list(dict.fromkeys(str(r["study_id"]) for r in categories))
    for sid in ids:
        block = [r for r in categories if str(r["study_id"]) == sid]
        block.sort(key=lambda r: int(r["category_order"]))
        ref = [r for r in block if bool(r["reference"])][0]
        country = str(ref["country"])
        gm, gsd = study_params.get(sid, distributions[country]["historical"])
        def representative(row):
            lo = float(row["lower_bq_m3"])
            hi = math.inf if bool(row["open_upper"]) else float(row["upper_bq_m3"])
            return lognormal_conditional_mean(lo, hi, gm, gsd)
        rm = representative(ref)
        for row in block:
            if bool(row["reference"]):
                continue
            cm = representative(row)
            source_contrasts.append({
                "study_id": sid, "country": country,
                "comparison_level": str(row["reported_level"]), "reference_level": str(ref["reported_level"]),
                "log_or": math.log(float(row["adjusted_or"])),
                "se_log_or": (math.log(float(row["ci_upper"])) - math.log(float(row["ci_lower"]))) / 3.92,
                "comparison_mean": cm, "reference_mean": rm, "x": cm - rm,
            })
    source_fit = fit_radon_contrasts(source_contrasts, rho=0.5)["random_effects"]

    import csv
    with OUT_RADON_CSV.open("w", newline="", encoding="utf-8") as fh:
        fields = sorted(set().union(*(x.keys() for x in study_checks)))
        w = csv.DictWriter(fh, fieldnames=fields); w.writeheader(); w.writerows(study_checks)

    return {
        "base_historical": {
            "beta": base_fit["beta"], "tau": base_fit["tau"],
            "or_per_100": base_fit["or_per_100_bq_m3"], "ci_per_100": base_fit["or_ci_per_100_bq_m3"],
        },
        "darby_category_mean_check": {
            "source": "Darby et al. 2005 pooled European individual-data analysis, Table 2",
            "categories": darby_check,
            "mean_absolute_percent_difference_all_categories": float(np.mean([abs(x["percent_difference"]) for x in darby_check])),
            "mean_absolute_percent_difference_nonreference_categories": float(np.mean([abs(x["percent_difference"]) for x in darby_check if x["category"] != "<25"])),
            "override_sensitivity_or_per_100": darby_fit["or_per_100_bq_m3"],
            "override_sensitivity_ci_per_100": darby_fit["or_ci_per_100_bq_m3"],
        },
        "lubin1997_study_level_checks": study_checks,
        "source_informed_five_study_sensitivity": {
            "n_studies_recalibrated": len(study_params),
            "beta": source_fit["beta"], "tau": source_fit["tau"],
            "or_per_100": source_fit["or_per_100_bq_m3"], "ci_per_100": source_fit["or_ci_per_100_bq_m3"],
            "interpretation": "sensitivity only; Lubin table summaries and Pavia extracted samples are not perfectly identical",
        },
    }


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--outer", type=int, default=200)
    ap.add_argument("--inner", type=int, default=199)
    ap.add_argument("--factor-reps", type=int, default=500)
    ap.add_argument("--skip-bootstrap", action="store_true")
    ap.add_argument("--skip-factorial", action="store_true")
    args = ap.parse_args()

    out = {"radon_first_stage_plausibility": radon_first_stage_plausibility()}
    if not args.skip_bootstrap:
        out["studentized_bootstrap_coverage"] = run_bootstrap_coverage(args.outer, args.inner)
    if not args.skip_factorial:
        out["generic_factorial"] = run_generic_factorial(args.factor_reps)
    OUT_JSON.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps({
        "radon": out["radon_first_stage_plausibility"],
        "bootstrap": out.get("studentized_bootstrap_coverage"),
        "factorial_overall": out.get("generic_factorial", {}).get("overall"),
        "factorial_factor_summary": out.get("generic_factorial", {}).get("factor_summary"),
    }, indent=2))


if __name__ == "__main__":
    main()
