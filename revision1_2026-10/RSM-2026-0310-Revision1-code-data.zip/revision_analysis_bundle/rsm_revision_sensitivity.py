#!/usr/bin/env python3
"""Exploratory RSM revision analyses for Reviewer 1 M2-M4.

This script does NOT edit the manuscript. It reproduces the submitted AFO
baseline from the analysis workbook and runs revision-specific exploratory
analyses:
  * M2: nonexchangeable within-study correlation sensitivities;
  * M3: source-informed Gamma exposure-distribution calibration;
  * M4a: three conventional assigned-value/open-category comparators;
  * M4b: d_max +/-20% sensitivity for the proposed conditional-mean mapping;
  * M4c: nonlinear application sensitivity using an added E[log(1+D)|S] basis;
  * M4d: individual-level adjusted-OR simulation with common/differing adequate
         adjustment, inadequate adjustment, and beta=0 with tau>0.

The source-informed calibration constants are documented in SOURCE_NOTES below.
They are drawn from source articles and are intended for revision exploration;
they should be re-audited before final manuscript use.
"""
from __future__ import annotations

import json, math, warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
from openpyxl import load_workbook
from scipy.integrate import quad
from scipy.optimize import minimize_scalar, least_squares, brentq
from scipy.stats import gamma, norm, t as student_t
from scipy.special import expit

INPUT = Path(__file__).resolve().parent / 'Observed Data.xlsx'
OUT = Path(__file__).resolve().parent / 'rsm_revision_sensitivity_results.json'
CSV = Path(__file__).resolve().parent / 'rsm_revision_m3_row_mapping.csv'

REGION_PARAMS = {
    'Netherlands': (2.640331, 0.220433),
    'NC': (1.809830, 5.193423),
    'PA': (2.059092, 2.108859),
    'Wisconsin': (1.900381, 6.181165),
}
SCHULTZ = 32508669

# Source-study exposure information used for exploratory calibration.
SOURCE_NOTES = {
    'Rasmussen 2017': '8,399/35,269 study participants lived within 3 miles of qualifying IFAP; one condition.',
    'Smit 2014 nearest farm': 'Nearest-farm categories 50-280, 280-440, 440-640, >640 m were quartiles; fit conditional on D>50m.',
    'Smit 2014 swine': 'Swine farm within 500m: 7,641/22,406 children and 22,542/70,142 adults; pooled proportion used.',
    'Smit 2012 swine': 'Adult contrast; 82.4% of 68,989 adult controls had swine within 1 km; one condition.',
    'Freidl pig': 'Combined cases/noncases: pig farm within 500/1000/1500m = 686/2426, 1925/2426, 2355/2426.',
    'Freidl goat distance': 'Reported goat-distance quartiles with boundaries 1629,2478,3490m; fit quartile constraints.',
    'Freidl poultry distance': 'Reported poultry-distance quartiles with boundaries 644,923,1296m; plus 2215/2426 within 2000m.',
    'Post poultry': 'Adult study: poultry farm within 500/1000/1500/2000m = 10.78%,46.76%,79.79%,92.22%.',
    'Son 2021': 'At 15km, no-CAFO group n=348,394 of 1,195,272, so P(within15km)=0.70852; one condition.',
    'Schultz 2019': 'Retained rows are exact spline-evaluation points; distribution does not affect mapping.',
    'Simoes 2022': 'No nearest-facility distance distribution reported for pig-count buffer exposure; external Netherlands proxy retained.'
}

@dataclass
class Row:
    refid:int; author:str; effect_measure:str; exposure:str; value:str
    trt1:str; trt2:str; y:float; se:float; region:str; mapping_type:int
    c_lo:float; c_hi:float; r_lo:float; r_hi:float; dmax:Optional[float]


def num(x):
    if isinstance(x,str) and x.strip().lower() in {'inf','>inf'}: return math.inf
    return float(x)


def read_rows(path=INPUT):
    wb=load_workbook(path, data_only=True, read_only=True)
    ws=wb['Sheet1']
    vals=list(ws.iter_rows(min_row=1,max_row=34,values_only=True))
    hdr=list(vals[0])
    out=[]
    for rr in vals[1:]:
        d=dict(zip(hdr,rr))
        if d['Refid'] is None: continue
        se=(math.log(float(d['UL']))-math.log(float(d['LL'])))/3.92
        out.append(Row(
            int(d['Refid']), str(d['Author'] or '').strip(), str(d['effect_measure'] or '').upper(),
            str(d['exposure'] or ''), str(d['value'] or ''), str(d['trt1_name'] or ''), str(d['trt2_name'] or ''),
            math.log(float(d['EM'])), se, str(d['Region'] or ''), int(d['Type']),
            num(d['Contrast_distance_Lower']), num(d['Contrast_distance_Upper']),
            num(d['Control_distance_Lower']), num(d['Control_distance_Upper']),
            None if d['d_max'] is None else float(d['d_max'])
        ))
    return out


def supports(row:Row, dmax_mult=1.0):
    if row.refid==SCHULTZ:
        return (row.c_hi,row.c_hi),(row.r_hi,row.r_hi)
    dm=None if row.dmax is None else row.dmax*dmax_mult
    c_hi=row.c_hi
    if math.isinf(c_hi): c_hi=dm
    A=(row.c_lo,c_hi)
    if row.mapping_type==1:
        r_hi=row.r_hi
        if math.isinf(r_hi): r_hi=dm
        B=(row.r_lo,r_hi)
    else:
        # Type 2 source record stores 0-r vs 0-r; operational mapping is 0-r vs r-dmax.
        B=(c_hi,dm)
    return A,B


def prob_interval(lo,hi,a,scale):
    return gamma.cdf(hi,a=a,scale=scale)-gamma.cdf(lo,a=a,scale=scale)


def gamma_moment(lo,hi,a,scale,q=1):
    if lo==hi: return lo**q
    den=prob_interval(lo,hi,a,scale)
    if den<=1e-14: return np.nan
    coef=(scale**q)*math.exp(math.lgamma(a+q)-math.lgamma(a))
    num=gamma.cdf(hi,a=a+q,scale=scale)-gamma.cdf(lo,a=a+q,scale=scale)
    return coef*num/den


def gamma_log1p_mean(lo,hi,a,scale):
    if lo==hi: return math.log1p(lo)
    den=prob_interval(lo,hi,a,scale)
    if den<=1e-14: return np.nan
    # finite intervals in current application; integrate density directly.
    f=lambda x: math.log1p(x)*gamma.pdf(x,a=a,scale=scale)
    v=quad(f,lo,hi,epsabs=1e-9,epsrel=1e-8,limit=150)[0]/den
    return v


def midpoint(s): return s[0] if s[0]==s[1] else 0.5*(s[0]+s[1])


def row_group(row:Row):
    e=row.exposure.lower()
    v=row.value.lower()
    if row.refid==32507767:
        if '50 goats' in e: return 'goat_distance'
        if '250 poultry' in e: return 'poultry_distance'
        if v=='pig': return 'pig_buffer'
        if v=='poultry': return 'poultry_buffer'
    if row.refid==5:
        return 'nearest_farm' if 'distance to nearest farm' in e else 'swine_buffer'
    if row.refid==32509553: return 'poultry_buffer'
    if row.refid==32511496: return 'cafo_buffer'
    if row.refid==32512033: return 'pig_count_proxy'
    if row.refid==SCHULTZ: return 'spline'
    return e or 'default'


def fit_gamma_cdf(points, lower_trunc=0.0, initial=None):
    """Fit shape/scale by least squares on CDF constraints.

    points: list[(cut,p)] where p is CDF conditional on D>lower_trunc if lower_trunc>0.
    """
    if initial is None: initial=(2.5,0.5)
    def resid(z):
        a,sc=np.exp(z)
        F0=gamma.cdf(lower_trunc,a=a,scale=sc) if lower_trunc>0 else 0.0
        den=1-F0
        return np.array([((gamma.cdf(c,a=a,scale=sc)-F0)/den)-p for c,p in points])
    sol=least_squares(resid,np.log(initial),max_nfev=10000,xtol=1e-13,ftol=1e-13,gtol=1e-13)
    a,sc=np.exp(sol.x)
    return float(a),float(sc),float(np.sqrt(np.mean(resid(sol.x)**2)))


def scale_to_match(shape,r,p):
    # F_gamma(r; shape, scale)=p => scale = r / qgamma(p;shape,scale=1)
    q=gamma.ppf(p,a=shape,scale=1.0)
    return float(r/q)


def source_params(rows):
    """Return dict keyed (refid, group) => (shape,scale,note)."""
    out={}
    # Rasmussen one condition: within 3 miles = 8399/35269, borrow PA shape.
    a=REGION_PARAMS['PA'][0]; p=8399/35269
    out[(32509566,'default')]=(a,scale_to_match(a,3.0,p),'one source condition + PA external shape')

    # Smit 2014 nearest farm: quartiles conditional on D>50 m = 0.03107 mi.
    m2mi=1/1609.344
    lo=50*m2mi
    pts=[(280*m2mi,.25),(440*m2mi,.50),(640*m2mi,.75)]
    a,sc,rmse=fit_gamma_cdf(pts,lower_trunc=lo,initial=REGION_PARAMS['Netherlands'])
    out[(5,'nearest_farm')]=(a,sc,f'study quartile fit conditional D>50m; cdf-rmse={rmse:.4g}')
    # Smit 2014 swine within 500m; pooled children/adults prevalence.
    p=(7641+22542)/(22406+70142)
    a=REGION_PARAMS['Netherlands'][0]
    out[(5,'swine_buffer')]=(a,scale_to_match(a,500*m2mi,p),'one source condition + NL external shape')

    # Smit 2012 adult swine within 1km: use control prevalence 82.4%, adult OR row.
    a=REGION_PARAMS['Netherlands'][0]
    out[(7,'presence of farm animals within 1 km')]=(a,scale_to_match(a,1.0/1.609344,.824),'one adult-source condition + NL external shape')

    # Freidl pig buffer: combined cases/noncases p at 500,1000,1500 m.
    pig_pts=[(500*m2mi,686/2426),(1000*m2mi,1925/2426),(1500*m2mi,2355/2426)]
    a,sc,rmse=fit_gamma_cdf(pig_pts,initial=REGION_PARAMS['Netherlands'])
    out[(32507767,'pig_buffer')]=(a,sc,f'3 source CDF constraints; rmse={rmse:.4g}')
    # Freidl goat quartile distances.
    goat_pts=[(1629*m2mi,.25),(2478*m2mi,.50),(3490*m2mi,.75)]
    a,sc,rmse=fit_gamma_cdf(goat_pts,initial=(3.4,.5))
    out[(32507767,'goat_distance')]=(a,sc,f'3 source quartile constraints; rmse={rmse:.4g}')
    # Freidl poultry quartiles + 2000m overall prevalence.
    p2000=(175+2040)/2426
    poultry_pts=[(644*m2mi,.25),(923*m2mi,.50),(1296*m2mi,.75),(2000*m2mi,p2000)]
    a,sc,rmse=fit_gamma_cdf(poultry_pts,initial=(4,.16))
    out[(32507767,'poultry_distance')]=(a,sc,f'quartiles + 2000m source CDF; rmse={rmse:.4g}')
    out[(32507767,'poultry_buffer')]=(a,sc,'same qualifying-poultry source distribution as poultry distance')

    # Post adults: four poultry-buffer prevalences.
    post_pts=[(500*m2mi,.1078),(1000*m2mi,.4676),(1500*m2mi,.7979),(2000*m2mi,.9222)]
    a,sc,rmse=fit_gamma_cdf(post_pts,initial=REGION_PARAMS['Netherlands'])
    out[(32509553,'poultry_buffer')]=(a,sc,f'4 source CDF constraints; rmse={rmse:.4g}')

    # Son: one directly extractable condition from Table 1 at 15 km.
    p=1-348394/1195272
    a=REGION_PARAMS['NC'][0]
    out[(32511496,'cafo_buffer')]=(a,scale_to_match(a,15/1.609344,p),'one 15-km source condition + NC external shape')
    return out


def params_for(row,sp,use_source=True):
    if use_source:
        key=(row.refid,row_group(row))
        if key in sp: return sp[key][0],sp[key][1],sp[key][2]
        # Smit 2012 group label from row_group is exposure text (lowercase); special fallback
        if row.refid==7:
            v=sp[(7,'presence of farm animals within 1 km')]
            return v
    a,sc=REGION_PARAMS.get(row.region,REGION_PARAMS['Netherlands'])
    return a,sc,'external regional distribution'


def design(rows,sp=None,use_source=False,dmax_mult=1.0,assigned_rule=None,basis='linear'):
    vals=[]
    for row in rows:
        A,B=supports(row,dmax_mult)
        if assigned_rule:
            # Exact/Type1: conventional midpoint of current finite support.
            if row.refid==SCHULTZ or row.mapping_type==1:
                va,vb=midpoint(A),midpoint(B)
            else:
                r=A[1]
                va=r/2
                if assigned_rule=='finite_midpoint': vb=(r+B[1])/2
                elif assigned_rule=='equal_adjacent_width': vb=1.5*r
                elif assigned_rule=='upper_1p2': vb=1.2*r
                else: raise ValueError(assigned_rule)
            vals.append(va-vb); continue
        a,sc,_=params_for(row,sp,use_source)
        if basis=='linear': f=lambda S: gamma_moment(*S,a,sc,q=1)
        elif basis=='quadratic': f=lambda S: gamma_moment(*S,a,sc,q=2)
        elif basis=='log1p': f=lambda S: gamma_log1p_mean(*S,a,sc)
        else: raise ValueError(basis)
        vals.append(f(A)-f(B))
    return np.array(vals,float)


def study_indices(rows):
    ids=[]
    for r in rows:
        if r.refid not in ids: ids.append(r.refid)
    return [(rid,np.array([i for i,r in enumerate(rows) if r.refid==rid],int)) for rid in ids]


def correlation_matrix(rows_block,kind='exchangeable',rho=.5):
    n=len(rows_block)
    if kind=='exchangeable':
        C=np.full((n,n),rho); np.fill_diagonal(C,1); return C
    # PSD construction: global common component + block-specific exponential kernel + iid residual.
    if kind=='structured_moderate': base,amp,diag=0.15,0.65,0.20
    elif kind=='structured_strong': base,amp,diag=0.05,0.90,0.05
    else: raise ValueError(kind)
    C=base*np.ones((n,n)) + diag*np.eye(n)
    groups=[row_group(r) for r in rows_block]
    # block diagonal kernel by exposure definition, based on comparison radius/point.
    for g in sorted(set(groups)):
        ix=[i for i,x in enumerate(groups) if x==g]
        radii=[]
        for i in ix:
            r=rows_block[i]
            if r.refid==SCHULTZ: rad=r.c_hi
            else: rad=r.c_hi if math.isfinite(r.c_hi) else (r.dmax or 1)
            radii.append(rad)
        radii=np.array(radii,float)
        span=max(float(np.ptp(radii)),0.25)
        L=max(span/2,0.25)
        K=np.exp(-np.abs(radii[:,None]-radii[None,:])/L)
        C[np.ix_(ix,ix)] += amp*K
    # numeric normalization (diagonal should already be 1)
    d=np.sqrt(np.diag(C)); C=C/d[:,None]/d[None,:]
    return C


def cov_blocks(rows,corr_kind='exchangeable',rho=.5):
    blocks=[]
    for rid,ix in study_indices(rows):
        rb=[rows[i] for i in ix]
        se=np.array([r.se for r in rb])
        C=correlation_matrix(rb,corr_kind,rho)
        eig=np.linalg.eigvalsh(C)
        if eig.min()<=1e-8:
            raise RuntimeError((rid,corr_kind,eig.min()))
        S=np.diag(se)@C@np.diag(se)
        blocks.append((rid,ix,S,C))
    return blocks


def fit_reml(rows,x,corr_kind='exchangeable',rho=.5,X_extra=None):
    y=np.array([r.y for r in rows])
    X=x[:,None] if X_extra is None else np.column_stack([x,X_extra])
    z=x.copy() # random slope applies to linear exposure design only
    blocks=cov_blocks(rows,corr_kind,rho)
    p=X.shape[1]
    def at_tau(tau,detail=False):
        XtViX=np.zeros((p,p)); XtViy=np.zeros(p); logdet=0.0
        mats=[]
        for rid,ix,S,C in blocks:
            zz=z[ix]
            V=S+tau*tau*np.outer(zz,zz)
            sign,ld=np.linalg.slogdet(V)
            if sign<=0: return None
            Vi=np.linalg.inv(V); Xi=X[ix]; yi=y[ix]
            XtViX += Xi.T@Vi@Xi; XtViy += Xi.T@Vi@yi; logdet += ld
            mats.append((ix,Vi,yi,Xi))
        try: beta=np.linalg.solve(XtViX,XtViy)
        except np.linalg.LinAlgError: return None
        q=0.0
        for ix,Vi,yi,Xi in mats:
            rr=yi-Xi@beta; q += rr@Vi@rr
        sign,ldx=np.linalg.slogdet(XtViX)
        if sign<=0:return None
        nll=.5*(logdet+q+ldx)
        if detail:
            covb=np.linalg.inv(XtViX)
            return nll,beta,covb,q
        return nll
    # generous data-driven tau bracket
    upper=max(2.0,5*np.std(y)/(max(np.std(x),1e-4)))
    obj=lambda t: at_tau(t) if at_tau(t) is not None else 1e100
    opt=minimize_scalar(obj,bounds=(0,upper),method='bounded',options={'xatol':1e-10})
    cand=[(0.0,obj(0.0)),(float(opt.x),float(opt.fun))]
    tau,minv=min(cand,key=lambda q:q[1])
    nll,beta,covb,q=at_tau(tau,True)
    se=np.sqrt(np.diag(covb)); K=len(blocks)
    ci_norm=np.column_stack([beta-1.96*se,beta+1.96*se])
    tc=student_t.ppf(.975,K-1)
    ci_t=np.column_stack([beta-tc*se,beta+tc*se])
    return {'beta':beta.tolist(),'se':se.tolist(),'tau':tau,'normal_ci':ci_norm.tolist(),'t_ci':ci_t.tolist(),'Q':q,'K':K,'n':len(rows),'corr_kind':corr_kind}


def fit_summary(f):
    b=f['beta'][0]; lo,hi=f['normal_ci'][0]
    return {'beta':b,'OR_per_mile':math.exp(b),'CI_OR':[math.exp(lo),math.exp(hi)],'tau':f['tau'],'se':f['se'][0]}


def m3_row_audit(rows,sp,x_old,x_new):
    import csv
    rec=[]
    for i,r in enumerate(rows):
        a0,s0=REGION_PARAMS.get(r.region,REGION_PARAMS['Netherlands'])
        a1,s1,note=params_for(r,sp,True)
        rec.append({
            'row':i+2,'author':r.author,'exposure':r.exposure,'value':r.value,'group':row_group(r),
            'old_shape':a0,'old_scale':s0,'new_shape':a1,'new_scale':s1,'calibration':note,
            'x_old':x_old[i],'x_source':x_new[i],
            'pct_change_abs_x': (abs(x_new[i])-abs(x_old[i]))/abs(x_old[i])*100 if abs(x_old[i])>1e-12 else np.nan
        })
    with CSV.open('w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=rec[0].keys()); w.writeheader(); w.writerows(rec)
    return rec

# ---------- Adjusted-OR simulation ----------
def logit_fit(X,y,maxit=30,tol=1e-8):
    """Small Newton/IRLS logistic regression returning beta and covariance."""
    p=X.shape[1]; b=np.zeros(p)
    # initialize intercept from event rate
    py=np.clip(y.mean(),1e-4,1-1e-4); b[0]=math.log(py/(1-py))
    for _ in range(maxit):
        eta=X@b; mu=expit(np.clip(eta,-30,30)); w=np.clip(mu*(1-mu),1e-6,None)
        H=X.T@(w[:,None]*X)
        g=X.T@(y-mu)
        try: step=np.linalg.solve(H,g)
        except np.linalg.LinAlgError: return None
        b2=b+step
        if np.max(np.abs(step))<tol: b=b2; break
        b=b2
    eta=X@b; mu=expit(np.clip(eta,-30,30)); w=np.clip(mu*(1-mu),1e-6,None)
    H=X.T@(w[:,None]*X)
    try: cov=np.linalg.inv(H)
    except np.linalg.LinAlgError:return None
    return b,cov


def fit_meta_arrays(y_blocks,S_blocks,x_blocks):
    K=len(y_blocks); p=1
    def at_tau(tau,detail=False):
        A=0.; c=0.; ld=0.; mats=[]
        for y,S,x in zip(y_blocks,S_blocks,x_blocks):
            V=S+tau*tau*np.outer(x,x)
            sign,l=np.linalg.slogdet(V)
            if sign<=0:return None
            Vi=np.linalg.inv(V); A += x@Vi@x; c += x@Vi@y; ld+=l; mats.append((y,Vi,x))
        if A<=0:return None
        b=c/A; q=sum((y-b*x)@Vi@(y-b*x) for y,Vi,x in mats)
        nll=.5*(ld+q+math.log(A))
        if detail:return nll,b,math.sqrt(1/A),q
        return nll
    upper=1.5
    obj=lambda t: at_tau(t) if at_tau(t) is not None else 1e100
    o=minimize_scalar(obj,bounds=(0,upper),method='bounded',options={'xatol':1e-8})
    t=0.0 if obj(0)<=o.fun else float(o.x)
    _,b,se,q=at_tau(t,True)
    return b,t,se


def adjusted_or_sim(seed=20261001,R=500,K=10,n=1500,beta=-.08,tau=.06):
    scenarios=['common_adequate','different_adequate','inadequate','null_with_heterogeneity']
    out={}
    for scenario in scenarios:
        # Use the same Monte Carlo stream across scenarios so adequate/inadequate
        # adjustment comparisons are paired on the underlying simulated data.
        rng=np.random.default_rng(seed)
        bt=0.0 if scenario=='null_with_heterogeneity' else beta
        est=[]; taus=[]; ses=[]; failures=0
        for rep in range(R):
            yb=[]; Sb=[]; xb=[]
            for k in range(K):
                C1=rng.normal(size=n); C2=rng.normal(size=n); C3=rng.normal(size=n)
                eps=rng.normal(size=n)
                # positive, right-skewed exposure correlated with C1,C2
                D=np.exp(0.15 + .30*C1 + .20*C2 + .55*eps)
                q1,q2=np.quantile(D,[1/3,2/3])
                cat=np.digitize(D,[q1,q2])
                m=np.array([D[cat==j].mean() for j in range(3)])
                x=np.array([m[1]-m[0],m[2]-m[0]])
                s=bt+rng.normal(0,tau)
                eta=-2.2+s*D+.55*C1-.45*C2+.65*C3
                Y=rng.binomial(1,expit(np.clip(eta,-30,30)))
                d1=(cat==1).astype(float); d2=(cat==2).astype(float)
                if scenario in ['common_adequate','null_with_heterogeneity']:
                    covs=[C1,C2]
                elif scenario=='different_adequate':
                    covs=[C1,C2] if k%2==0 else [C1,C2,C3]
                else: # omit C2, a true exposure-outcome confounder
                    covs=[C1]
                X=np.column_stack([np.ones(n),d1,d2,*covs])
                fit=logit_fit(X,Y)
                if fit is None:
                    failures+=1; continue
                bh,V=fit
                yb.append(np.array([bh[1],bh[2]])); Sb.append(V[1:3,1:3]); xb.append(x)
            if len(yb)<K:
                continue
            b,t,se=fit_meta_arrays(yb,Sb,xb); est.append(b); taus.append(t); ses.append(se)
        est=np.array(est); taus=np.array(taus); ses=np.array(ses)
        target=bt
        z=(est-target)/ses
        tc=student_t.ppf(.975,K-1)
        out[scenario]={
            'R_requested':R,'R_completed':len(est),'failures':failures,'beta_true':target,'tau_true':tau,
            'mean_beta':float(est.mean()),'bias':float(est.mean()-target),'rmse':float(np.sqrt(np.mean((est-target)**2))),
            'mean_tau':float(taus.mean()),'mean_se':float(ses.mean()),
            'normal_coverage':float(np.mean(np.abs(z)<=1.96)),
            't_coverage':float(np.mean(np.abs(z)<=tc)),
            'type1_normal':float(np.mean(np.abs(z)>1.96)) if target==0 else None,
            'type1_t':float(np.mean(np.abs(z)>tc)) if target==0 else None,
        }
    return out


def main():
    rows=read_rows(); sp=source_params(rows)
    x_old=design(rows,use_source=False)
    base=fit_reml(rows,x_old)
    # verify submitted numbers
    x_new=design(rows,sp,use_source=True)
    m3=fit_reml(rows,x_new)
    rec=m3_row_audit(rows,sp,x_old,x_new)

    m2={}
    for kind in ['exchangeable','structured_moderate','structured_strong']:
        m2[kind]=fit_summary(fit_reml(rows,x_new,corr_kind=kind,rho=.5))

    assigned={}
    for rule in ['finite_midpoint','equal_adjacent_width','upper_1p2']:
        xx=design(rows,assigned_rule=rule)
        assigned[rule]=fit_summary(fit_reml(rows,xx))

    dmax={}
    for mult in [.8,1.0,1.2]:
        xx=design(rows,sp,use_source=True,dmax_mult=mult)
        dmax[str(mult)]=fit_summary(fit_reml(rows,xx))

    # Nonlinear: add source-informed support average of log(1+D) as curvature basis.
    xlog=design(rows,sp,use_source=True,basis='log1p')
    nonlinear=fit_reml(rows,x_new,X_extra=xlog)
    b2=nonlinear['beta'][1]; se2=nonlinear['se'][1]
    nonlinear_summary={
        'linear_beta':nonlinear['beta'][0],'linear_se':nonlinear['se'][0],
        'log1p_curvature_beta':b2,'log1p_curvature_se':se2,
        'curvature_z':b2/se2,'curvature_p_2sided':2*norm.sf(abs(b2/se2)),
        'tau':nonlinear['tau'],'normal_ci':nonlinear['normal_ci'],
    }

    # M3 diagnostics: largest row changes + params
    finite_changes=[r for r in rec if np.isfinite(r['pct_change_abs_x'])]
    finite_changes.sort(key=lambda z:abs(z['pct_change_abs_x']),reverse=True)
    param_report={f'{rid}|{grp}':{'shape':v[0],'scale':v[1],'mean':v[0]*v[1],'note':v[2]} for (rid,grp),v in sp.items()}

    sim=adjusted_or_sim(R=500)

    result={
        'input':str(INPUT),
        'baseline_submitted_reproduction':fit_summary(base),
        'm3_source_informed':fit_summary(m3),
        'm3_source_params':param_report,
        'm3_source_notes':SOURCE_NOTES,
        'm3_largest_absolute_percent_x_changes':finite_changes[:12],
        'm2_structured_correlation':m2,
        'm4_assigned_value_comparators':assigned,
        'm4_source_informed_dmax_sensitivity':dmax,
        'm4_nonlinear_log1p_sensitivity':nonlinear_summary,
        'm4_adjusted_or_simulation':sim,
    }
    OUT.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
