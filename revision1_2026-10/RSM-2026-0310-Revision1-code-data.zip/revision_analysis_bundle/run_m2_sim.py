import sys,importlib.util,json,math,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
import numpy as np
from scipy.stats import t as student_t
spec=importlib.util.spec_from_file_location('rr',str(HERE/'rsm_revision_sensitivity.py'))
m=importlib.util.module_from_spec(spec); sys.modules['rr']=m; spec.loader.exec_module(m)
rows=m.read_rows(); sp=m.source_params(rows); x=m.design(rows,sp,use_source=True)
blocks=m.study_indices(rows)
# fitted covariance exchangeable .5
fit_blocks=m.cov_blocks(rows,'exchangeable',.5)
Sfit=[b[2] for b in fit_blocks]; xb=[x[ix] for _,ix in blocks]
beta=-0.06370390007335337; tau=.11722305891289918
out={}
for kind in ['structured_moderate','structured_strong']:
    true_blocks=m.cov_blocks(rows,kind,.5); Str=[b[2] for b in true_blocks]
    rng=np.random.default_rng(20261002)
    R=500; be=[]; te=[]; se=[]
    for rep in range(R):
        ys=[]
        for xx,S in zip(xb,Str):
            slope=beta+rng.normal(0,tau)
            ys.append(slope*xx+rng.multivariate_normal(np.zeros(len(xx)),S))
        b,t,s=m.fit_meta_arrays(ys,Sfit,xb); be.append(b);te.append(t);se.append(s)
    be=np.array(be);te=np.array(te);se=np.array(se); z=(be-beta)/se
    tc=student_t.ppf(.975,len(xb)-1)
    out[kind]={'R':R,'beta_true':beta,'tau_true':tau,'mean_beta':be.mean(),'bias':be.mean()-beta,'rmse':np.sqrt(np.mean((be-beta)**2)),'mean_tau':te.mean(),'mean_se':se.mean(),'normal_coverage':np.mean(abs(z)<=1.96),'t_coverage':np.mean(abs(z)<=tc)}
print(json.dumps(out,indent=2))
open(HERE/'rsm_m2_structured_corr_sim.json','w').write(json.dumps(out,indent=2))
