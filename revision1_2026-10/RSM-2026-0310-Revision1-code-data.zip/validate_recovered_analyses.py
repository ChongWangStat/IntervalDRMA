from pathlib import Path
import sys, importlib.util, json, hashlib
import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
ARCH = ROOT / 'calibration_audit' / 'reference_copy'
OUT = ROOT / 'calibration_audit'
if not ARCH.exists():
    import zipfile
    ARCH.mkdir(parents=True)
    with zipfile.ZipFile(ROOT / 'RSM_revision_reproducibility_bundle.zip') as z:
        z.extractall(ARCH)
OUT.mkdir(parents=True, exist_ok=True)
manifest = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ARCH.iterdir() if p.is_file()}
spec = importlib.util.spec_from_file_location('revision_archive',ARCH/'rsm_revision_sensitivity.py')
rr = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = rr
spec.loader.exec_module(rr)
rows=rr.read_rows(ARCH/'Observed Data.xlsx')
sp=rr.source_params(rows)
original=json.loads((ARCH/'rsm_revision_sensitivity_results_consolidated.json').read_text())
x=rr.design(rows,sp,use_source=True)
fit=rr.fit_reml(rows,x)
assert abs(fit['beta'][0]-original['m3_source_informed']['beta'])<1e-8
assert abs(fit['tau']-original['m3_source_informed']['tau'])<1e-7

def detailed_fit(rs,xx,**kwargs):
    f=rr.fit_reml(rs,xx,**kwargs)
    res=[]
    for _,ix,S,_ in rr.cov_blocks(rs,kwargs.get('corr_kind','exchangeable'),kwargs.get('rho',.5)):
        V=S+f['tau']**2*np.outer(xx[ix],xx[ix])
        y=np.array([rs[i].y for i in ix])
        X=xx[ix,None] if kwargs.get('X_extra') is None else np.column_stack([xx[ix],kwargs['X_extra'][ix]])
        res.extend(np.linalg.solve(np.linalg.cholesky(V),y-X@np.array(f['beta'])).tolist())
    f['max_abs_decorrelated_residual']=float(max(abs(v) for v in res))
    f['OR_per_mile']=float(np.exp(f['beta'][0]))
    f['normal_OR_CI']=np.exp(f['normal_ci'][0]).tolist()
    f['t_OR_CI']=np.exp(f['t_ci'][0]).tolist()
    return f

audit={'archive_sha256':manifest,'archived_fit_reproduced':detailed_fit(rows,x),'unmatched_calibration_keys':[]}
for row in rows:
    key=(row.refid,rr.row_group(row))
    if row.refid==32509566:
        audit['unmatched_calibration_keys'].append({'study':row.author,'looked_up':list(key),'available':[32509566,'default'],'archived_x':float(x[rows.index(row)])})

# Audit-only correction in memory: the archive is never modified.
sp_complete=dict(sp)
rasm=next(r for r in rows if r.refid==32509566)
sp_complete[(rasm.refid,rr.row_group(rasm))]=sp[(32509566,'default')]
xc=rr.design(rows,sp_complete,use_source=True)
audit['all_recorded_calibrations_applied']=detailed_fit(rows,xc)
audit['complete_mapping_correlations']={kind:detailed_fit(rows,xc,corr_kind=kind) for kind in ['exchangeable','structured_moderate','structured_strong']}
audit['complete_mapping_dmax']={str(v):detailed_fit(rows,rr.design(rows,sp_complete,use_source=True,dmax_mult=v)) for v in [.8,1,1.2]}
audit['complete_mapping_nonlinear']=detailed_fit(rows,xc,X_extra=rr.design(rows,sp_complete,use_source=True,basis='log1p'))
for name,ix in [('OR_only',[i for i,r in enumerate(rows) if r.effect_measure=='OR']),('strict_explicit_OR',[i for i,r in enumerate(rows) if r.effect_measure=='OR' and r.mapping_type==1])]:
    audit[name]=detailed_fit([rows[i] for i in ix],xc[ix])
audit['rows']=[]
for i,r in enumerate(rows):
    a,sc,note=rr.params_for(r,sp_complete,True)
    A,B=rr.supports(r)
    audit['rows'].append({'row':i+2,'study':r.author,'refid':r.refid,'type':r.mapping_type,'effect_measure':r.effect_measure,'group':rr.row_group(r),'A':A,'B':B,'shape':a,'scale':sc,'mean_A':rr.gamma_moment(*A,a,sc),'mean_B':rr.gamma_moment(*B,a,sc),'archived_x':float(x[i]),'complete_x':float(xc[i]),'calibration':note})
after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ARCH.iterdir() if p.is_file()}
assert manifest==after
audit['archive_unchanged']=True
(OUT/'recovered_analysis_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in audit.items() if k not in ['rows','archive_sha256']},indent=2))
